import React, { createContext, useContext, useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { UserProfile, Transaction, Mission, ResponsibleGamingSettings, GameType } from '../types/casino';
import { sounds } from '../services/soundEffects';

interface CasinoContextType {
  user: UserProfile;
  activeTab: GameType;
  setActiveTab: (tab: GameType) => void;
  transactions: Transaction[];
  missions: Mission[];
  responsibleSettings: ResponsibleGamingSettings;
  updateResponsibleSettings: (settings: Partial<ResponsibleGamingSettings>) => void;
  isMuted: boolean;
  toggleMute: () => void;
  depositPix: (amountBRL: number) => { success: boolean; message: string };
  withdrawPix: (amountLC: number, pixKey: string) => { success: boolean; message: string; netBRL?: number };
  placeBet: (game: string, betLC: number) => boolean;
  registerWin: (game: string, betLC: number, winLC: number, isJackpot?: boolean) => void;
  claimDailyReward: () => number;
  claimMissionReward: (missionId: string) => void;
  claimCashback: () => number;
  sessionElapsedSeconds: number;
  triggerConfetti: () => void;
  checkSelfExclusion: () => boolean;
  endSelfExclusionForTesting: () => void;
  triggerTimeWarning: boolean;
  dismissTimeWarning: () => void;
}

const DEFAULT_USER: UserProfile = {
  id: 'usr_lula_888',
  name: 'Jogador Campeão',
  cpf: '551.908.838-17',
  email: 'apostador@lulacoins.com.br',
  balanceLC: 5000, // Começa com 5.000 LC de boas-vindas
  totalDepositedBRL: 50,
  totalWithdrawnBRL: 0,
  vipTier: 'Bronze',
  vipXP: 320,
  cashbackAvailableLC: 150,
  lastDailyClaim: null,
  dailyStreak: 3,
};

const DEFAULT_MISSIONS: Mission[] = [
  {
    id: 'm1',
    title: 'Giro da Sorte',
    description: 'Faça 10 giros no Caça-Níquel Lula Fortune',
    rewardLC: 350,
    progress: 4,
    target: 10,
    completed: false,
    claimed: false,
  },
  {
    id: 'm2',
    title: 'Mestre da Mesa',
    description: 'Faça 3 apostas na Roleta Real',
    rewardLC: 500,
    progress: 1,
    target: 3,
    completed: false,
    claimed: false,
  },
  {
    id: 'm3',
    title: 'Vinte e Um',
    description: 'Ganhe 1 mão no Blackjack 21',
    rewardLC: 600,
    progress: 0,
    target: 1,
    completed: false,
    claimed: false,
  },
  {
    id: 'm4',
    title: 'Membro da Realeza',
    description: 'Acumule 100 XP no programa VIP',
    rewardLC: 1000,
    progress: 75,
    target: 100,
    completed: false,
    claimed: false,
  },
];

const DEFAULT_RESPONSIBLE: ResponsibleGamingSettings = {
  dailyDepositLimitBRL: 500,
  dailyLossLimitLC: 10000,
  sessionTimeLimitMinutes: 30,
  sessionStartTime: Date.now(),
  isSelfExcluded: false,
  selfExclusionUntil: null,
  breakTimerActive: false,
};

const CasinoContext = createContext<CasinoContextType | undefined>(undefined);

export const CasinoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('lula_casino_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  const [activeTab, setActiveTab] = useState<GameType>('slots');
  const [isMuted, setIsMuted] = useState(false);
  const [sessionStartTime] = useState(Date.now());
  const [sessionElapsedSeconds, setSessionElapsedSeconds] = useState(0);
  const [triggerTimeWarning, setTriggerTimeWarning] = useState(false);

  const [responsibleSettings, setResponsibleSettings] = useState<ResponsibleGamingSettings>(() => {
    const saved = localStorage.getItem('lula_casino_responsible');
    return saved ? JSON.parse(saved) : DEFAULT_RESPONSIBLE;
  });

  const [missions, setMissions] = useState<Mission[]>(() => {
    const saved = localStorage.getItem('lula_casino_missions');
    return saved ? JSON.parse(saved) : DEFAULT_MISSIONS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('lula_casino_txs');
    return saved ? JSON.parse(saved) : [
      {
        id: 'tx_init',
        type: 'daily_bonus',
        amountLC: 5000,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: 'Bônus de Boas-Vindas Lula Coins'
      }
    ];
  });

  // Track session duration & alert
  useEffect(() => {
    const timer = setInterval(() => {
      const elapsed = Math.floor((Date.now() - sessionStartTime) / 1000);
      setSessionElapsedSeconds(elapsed);

      const limitSec = responsibleSettings.sessionTimeLimitMinutes * 60;
      if (limitSec > 0 && elapsed > 0 && elapsed % limitSec === 0) {
        setTriggerTimeWarning(true);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [sessionStartTime, responsibleSettings.sessionTimeLimitMinutes]);

  // Persist updates
  useEffect(() => {
    localStorage.setItem('lula_casino_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('lula_casino_responsible', JSON.stringify(responsibleSettings));
  }, [responsibleSettings]);

  useEffect(() => {
    localStorage.setItem('lula_casino_missions', JSON.stringify(missions));
  }, [missions]);

  useEffect(() => {
    localStorage.setItem('lula_casino_txs', JSON.stringify(transactions));
  }, [transactions]);

  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sounds.setMuted(next);
  };

  const triggerConfetti = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#facc15', '#ef4444', '#ca8a04', '#ffffff', '#b91c1c'],
    });
  };

  const checkSelfExclusion = (): boolean => {
    if (responsibleSettings.isSelfExcluded) {
      if (responsibleSettings.selfExclusionUntil && Date.now() > responsibleSettings.selfExclusionUntil) {
        // Exclusão expirou
        setResponsibleSettings(prev => ({
          ...prev,
          isSelfExcluded: false,
          selfExclusionUntil: null,
        }));
        return false;
      }
      return true;
    }
    return false;
  };

  const endSelfExclusionForTesting = () => {
    setResponsibleSettings(prev => ({
      ...prev,
      isSelfExcluded: false,
      selfExclusionUntil: null,
    }));
  };

  const updateResponsibleSettings = (newSettings: Partial<ResponsibleGamingSettings>) => {
    setResponsibleSettings(prev => ({ ...prev, ...newSettings }));
  };

  const dismissTimeWarning = () => setTriggerTimeWarning(false);

  // VIP Tier calculation
  const recalculateVip = (currentXP: number): 'Bronze' | 'Prata' | 'Ouro' | 'Platina' | 'Diamante' => {
    if (currentXP >= 5000) return 'Diamante';
    if (currentXP >= 2500) return 'Platina';
    if (currentXP >= 1000) return 'Ouro';
    if (currentXP >= 500) return 'Prata';
    return 'Bronze';
  };

  // Place Bet
  const placeBet = (game: string, betLC: number): boolean => {
    if (checkSelfExclusion()) return false;
    if (user.balanceLC < betLC) return false;

    // Deduct balance, add XP
    const newXP = user.vipXP + Math.max(1, Math.floor(betLC / 20));
    const newTier = recalculateVip(newXP);

    // Calculate cashback based on tier (Bronze: 2%, Prata: 4%, Ouro: 7%, Platina: 10%, Diamante: 15%)
    const cashbackRates = { Bronze: 0.02, Prata: 0.04, Ouro: 0.07, Platina: 0.10, Diamante: 0.15 };
    const cashbackEarned = Math.round(betLC * cashbackRates[newTier]);

    setUser(prev => ({
      ...prev,
      balanceLC: prev.balanceLC - betLC,
      vipXP: newXP,
      vipTier: newTier,
      cashbackAvailableLC: prev.cashbackAvailableLC + cashbackEarned,
    }));

    // Increment mission progress
    setMissions(prev => prev.map(m => {
      if (game.includes('slots') && m.id === 'm1') {
        const p = Math.min(m.target, m.progress + 1);
        return { ...m, progress: p, completed: p >= m.target };
      }
      if (game.includes('roulette') && m.id === 'm2') {
        const p = Math.min(m.target, m.progress + 1);
        return { ...m, progress: p, completed: p >= m.target };
      }
      return m;
    }));

    return true;
  };

  // Register Win
  const registerWin = (game: string, betLC: number, winLC: number, isJackpot: boolean = false) => {
    if (winLC > 0) {
      setUser(prev => ({
        ...prev,
        balanceLC: prev.balanceLC + winLC,
      }));

      // Audio & Visual celebratory triggers
      if (isJackpot) {
        sounds.playJackpotFanfare();
        triggerConfetti();
      } else {
        sounds.playWinJingle();
        sounds.playCoinSound();
      }

      // Add to tx log if significant
      setTransactions(prev => [
        {
          id: 'win_' + Date.now(),
          type: 'game_win',
          amountLC: winLC,
          timestamp: new Date().toLocaleTimeString('pt-BR'),
          status: 'concluido',
          description: `Vitória no ${game} (+${winLC.toLocaleString()} LC)`
        },
        ...prev.slice(0, 19)
      ]);

      if (game.includes('blackjack')) {
        setMissions(prev => prev.map(m => {
          if (m.id === 'm3') return { ...m, progress: 1, completed: true };
          return m;
        }));
      }
    }
  };

  // Deposit PIX
  const depositPix = (amountBRL: number): { success: boolean; message: string } => {
    if (checkSelfExclusion()) {
      return { success: false, message: 'Conta em período de autoexclusão. Depósitos bloqueados.' };
    }

    if (responsibleSettings.dailyDepositLimitBRL > 0) {
      if (amountBRL > responsibleSettings.dailyDepositLimitBRL) {
        return {
          success: false,
          message: `Limite diário de depósito excedido! Seu limite configurado é de R$ ${responsibleSettings.dailyDepositLimitBRL.toFixed(2)}.`,
        };
      }
    }

    // 1 BRL = 100 Lula Coins + Bônus progressivo
    let bonusMultiplier = 1.0;
    if (amountBRL >= 100) bonusMultiplier = 1.20; // 20% bonus
    else if (amountBRL >= 50) bonusMultiplier = 1.10; // 10% bonus

    const amountLC = Math.round(amountBRL * 100 * bonusMultiplier);

    setUser(prev => {
      const newXP = prev.vipXP + Math.round(amountBRL * 10);
      return {
        ...prev,
        balanceLC: prev.balanceLC + amountLC,
        totalDepositedBRL: prev.totalDepositedBRL + amountBRL,
        vipXP: newXP,
        vipTier: recalculateVip(newXP),
      };
    });

    setTransactions(prev => [
      {
        id: 'pix_dep_' + Date.now(),
        type: 'deposit_pix',
        amountLC,
        amountBRL,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: `Depósito PIX R$ ${amountBRL.toFixed(2)} (CPF: 551.908.838-17)`,
      },
      ...prev.slice(0, 19),
    ]);

    sounds.playCoinSound();
    triggerConfetti();

    return {
      success: true,
      message: `Depósito PIX de R$ ${amountBRL.toFixed(2)} confirmado! Você recebeu ${amountLC.toLocaleString()} Lula Coins.`,
    };
  };

  // Withdraw PIX (Reverse exchange with 5% fee)
  const withdrawPix = (amountLC: number, pixKey: string): { success: boolean; message: string; netBRL?: number } => {
    if (checkSelfExclusion()) {
      return { success: false, message: 'Conta em período de autoexclusão.' };
    }

    if (amountLC < 1000) {
      return { success: false, message: 'O valor mínimo para resgate é de 1.000 Lula Coins (R$ 10,00).' };
    }

    if (user.balanceLC < amountLC) {
      return { success: false, message: 'Saldo insuficiente em Lula Coins.' };
    }

    if (!pixKey || pixKey.trim().length < 5) {
      return { success: false, message: 'Por favor, informe uma chave PIX válida (CPF, Telefone, E-mail ou Chave Aleatória).' };
    }

    // Rate: 100 LC = R$ 1.00. Fee = 5%
    const grossBRL = amountLC / 100;
    const feeBRL = grossBRL * 0.05; // 5% taxa de troca reversa
    const netBRL = grossBRL - feeBRL;

    setUser(prev => ({
      ...prev,
      balanceLC: prev.balanceLC - amountLC,
      totalWithdrawnBRL: prev.totalWithdrawnBRL + netBRL,
    }));

    setTransactions(prev => [
      {
        id: 'pix_wth_' + Date.now(),
        type: 'withdraw_pix',
        amountLC,
        amountBRL: netBRL,
        feeBRL,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: `Resgate PIX enviado para ${pixKey} (Taxa 5%: R$ ${feeBRL.toFixed(2)})`,
      },
      ...prev.slice(0, 19),
    ]);

    sounds.playCoinSound();

    return {
      success: true,
      netBRL,
      message: `Resgate de ${amountLC.toLocaleString()} LC processado com sucesso! R$ ${netBRL.toFixed(2)} transferidos via PIX para ${pixKey} (Taxa de 5%: R$ ${feeBRL.toFixed(2)} deduzida).`,
    };
  };

  // Daily reward
  const claimDailyReward = (): number => {
    const today = new Date().toDateString();
    if (user.lastDailyClaim === today) {
      return 0;
    }

    // Rewards scale with daily streak
    const baseReward = 500;
    const bonus = user.dailyStreak * 150;
    const totalAward = baseReward + bonus;

    setUser(prev => ({
      ...prev,
      balanceLC: prev.balanceLC + totalAward,
      lastDailyClaim: today,
      dailyStreak: prev.dailyStreak + 1,
    }));

    setTransactions(prev => [
      {
        id: 'daily_' + Date.now(),
        type: 'daily_bonus',
        amountLC: totalAward,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: `Bônus Diário (Sequência de ${user.dailyStreak + 1} dias)`,
      },
      ...prev.slice(0, 19),
    ]);

    sounds.playJackpotFanfare();
    triggerConfetti();

    return totalAward;
  };

  // Claim Mission Reward
  const claimMissionReward = (missionId: string) => {
    const mission = missions.find(m => m.id === missionId);
    if (!mission || !mission.completed || mission.claimed) return;

    setUser(prev => ({
      ...prev,
      balanceLC: prev.balanceLC + mission.rewardLC,
    }));

    setMissions(prev => prev.map(m => m.id === missionId ? { ...m, claimed: true } : m));

    setTransactions(prev => [
      {
        id: 'mission_' + Date.now(),
        type: 'mission_reward',
        amountLC: mission.rewardLC,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: `Recompensa de Missão: ${mission.title}`,
      },
      ...prev.slice(0, 19),
    ]);

    sounds.playCoinSound();
    triggerConfetti();
  };

  // Claim VIP Cashback
  const claimCashback = (): number => {
    const amount = user.cashbackAvailableLC;
    if (amount <= 0) return 0;

    setUser(prev => ({
      ...prev,
      balanceLC: prev.balanceLC + amount,
      cashbackAvailableLC: 0,
    }));

    setTransactions(prev => [
      {
        id: 'cb_' + Date.now(),
        type: 'cashback',
        amountLC: amount,
        timestamp: new Date().toLocaleTimeString('pt-BR'),
        status: 'concluido',
        description: `Resgate de Cashback VIP (+${amount.toLocaleString()} LC)`,
      },
      ...prev.slice(0, 19),
    ]);

    sounds.playCoinSound();
    return amount;
  };

  return (
    <CasinoContext.Provider
      value={{
        user,
        activeTab,
        setActiveTab,
        transactions,
        missions,
        responsibleSettings,
        updateResponsibleSettings,
        isMuted,
        toggleMute,
        depositPix,
        withdrawPix,
        placeBet,
        registerWin,
        claimDailyReward,
        claimMissionReward,
        claimCashback,
        sessionElapsedSeconds,
        triggerConfetti,
        checkSelfExclusion,
        endSelfExclusionForTesting,
        triggerTimeWarning,
        dismissTimeWarning,
      }}
    >
      {children}
    </CasinoContext.Provider>
  );
};

export const useCasino = () => {
  const context = useContext(CasinoContext);
  if (!context) {
    throw new Error('useCasino must be used within a CasinoProvider');
  }
  return context;
};
