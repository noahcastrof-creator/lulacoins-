import React, { useState, useEffect } from 'react';
import { CasinoProvider, useCasino } from './context/CasinoContext';
import { Navbar } from './components/Navbar';
import { SlotGame } from './components/SlotGame';
import { RouletteGame } from './components/RouletteGame';
import { BlackjackGame } from './components/BlackjackGame';
import { LiveStudioGame } from './components/LiveStudioGame';
import { DepositPixModal } from './components/DepositPixModal';
import { WithdrawModal } from './components/WithdrawModal';
import { VipLoyalty } from './components/VipLoyalty';
import { DailyMissions } from './components/DailyMissions';
import { ResponsibleGamingModal } from './components/ResponsibleGamingModal';
import { WhitepaperConcept } from './components/WhitepaperConcept';
import { ResponsibleModals } from './components/ResponsibleModals';
import { Sparkles, Trophy, ShieldAlert, Award, ArrowRight } from 'lucide-react';

const COMMUNITY_WINS = [
  { user: 'Eduardo_BH', amount: 3200, game: 'Lula Fortune 777' },
  { user: 'Mariana_SP', amount: 7200, game: 'Roleta Real (Vermelho)' },
  { user: 'Thiago_RS', amount: 1250, game: 'Blackjack 21 Natural' },
  { user: 'Beatriz_PR', amount: 9400, game: 'Lula Fortune Jackpot' },
  { user: 'Gustavo_DF', amount: 2400, game: 'Mesa Ao Vivo' },
];

const CasinoMain: React.FC = () => {
  const { activeTab, setActiveTab, user } = useCasino();
  const [tickerIndex, setTickerIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTickerIndex((prev) => (prev + 1) % COMMUNITY_WINS.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const currentTicker = COMMUNITY_WINS[tickerIndex];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col justify-between selection:bg-amber-500 selection:text-neutral-950">
      
      {/* Top Navbar */}
      <div>
        <Navbar />

        {/* Live Community Wins Ticker */}
        <div className="bg-neutral-900/90 border-b border-red-950/40 py-2 px-4 text-xs">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 overflow-hidden text-neutral-300">
              <Trophy className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px] shrink-0">
                Ganhos Recentes:
              </span>
              <div className="truncate">
                <span className="font-semibold text-neutral-200">{currentTicker.user}</span>
                {' acabou de faturar '}
                <strong className="text-amber-300 font-mono-num font-bold">
                  +{currentTicker.amount.toLocaleString()} LC
                </strong>
                {' no '}
                <span className="text-neutral-400">{currentTicker.game}</span>
              </div>
            </div>

            <button
              onClick={() => setActiveTab('whitepaper')}
              className="hidden md:flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-semibold shrink-0 transition-colors"
            >
              <span>Ver Análise Regulatória & Tokenomics</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Game Navigation Hub / Quick Filter Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-2">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-neutral-800/80 no-scrollbar">
            {[
              { id: 'slots', label: '🎰 Caça-Níquel 777', badge: 'Mais Jogado' },
              { id: 'roulette', label: '🎡 Roleta Real', badge: '36x' },
              { id: 'blackjack', label: '🃏 Blackjack 21', badge: 'VIP' },
              { id: 'live', label: '🔴 Ao Vivo HD', badge: 'Crupiê' },
              { id: 'missions', label: '🎁 Bônus & Missões', badge: 'Grátis' },
              { id: 'vip', label: '👑 VIP & Loja', badge: '15% Cashback' },
              { id: 'deposit', label: '⚡ Recarregar PIX', badge: 'Instantâneo' },
              { id: 'withdraw', label: '🔄 Troca Reversa (Saque)', badge: '5% Taxa' },
              { id: 'responsible', label: '🛡️ Jogo Responsável', badge: 'Proteção' },
              { id: 'whitepaper', label: '📑 Conceito & Regulação', badge: 'Whitepaper' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-red-900 to-amber-900 text-amber-300 border border-amber-500/50 shadow-md shadow-red-950'
                    : 'bg-neutral-900/80 text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 border border-neutral-800'
                }`}
              >
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded font-extrabold ${
                    activeTab === tab.id ? 'bg-amber-400 text-neutral-950' : 'bg-neutral-800 text-neutral-400'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Active View Container */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'slots' && <SlotGame />}
          {activeTab === 'roulette' && <RouletteGame />}
          {activeTab === 'blackjack' && <BlackjackGame />}
          {activeTab === 'live' && <LiveStudioGame />}
          {activeTab === 'deposit' && <DepositPixModal />}
          {activeTab === 'withdraw' && <WithdrawModal />}
          {activeTab === 'vip' && <VipLoyalty />}
          {activeTab === 'missions' && <DailyMissions />}
          {activeTab === 'responsible' && <ResponsibleGamingModal />}
          {activeTab === 'whitepaper' && <WhitepaperConcept />}
        </main>
      </div>

      {/* Global Modals for Responsible Gaming alerts and self-exclusion */}
      <ResponsibleModals />

      {/* Footer */}
      <footer className="mt-16 bg-neutral-950 border-t border-red-950/60 py-10 px-4 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto space-y-6">
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 pb-6 border-b border-neutral-800">
            <div className="flex items-center gap-3">
              <img
                src="/src/assets/images/lula_coins_logo_1792135128596.jpg"
                alt="Lula Coins"
                className="w-9 h-9 rounded-full object-cover border border-amber-400/80 shadow"
              />
              <span className="font-cinzel font-bold text-neutral-300 text-sm">
                LULA COINS CASINO OFFICIAL
              </span>
            </div>

            {/* Regulatory & Safety Badges */}
            <div className="flex items-center gap-4 text-[11px]">
              <span className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-neutral-400 font-bold">
                +18 PROIBIDO PARA MENORES
              </span>
              <span className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-amber-400 font-semibold">
                JOGO RESPONSÁVEL
              </span>
              <span className="px-2 py-0.5 rounded bg-neutral-900 border border-neutral-800 text-emerald-400 font-semibold">
                PAGAMENTOS PIX INSTANTÂNEOS
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px] leading-relaxed text-neutral-400">
            <div>
              <strong className="text-neutral-300 block mb-1">Aviso Legal & Jogo Responsável:</strong>
              O jogo deve ser tratado estritamente como forma de entretenimento casual. Estabeleça limites de tempo e gasto antes de apostar. Se você ou alguém que você conhece apresentar sinais de compulsão, procure auxílio em jogadoresanonimos.com.br ou ligue gratuitamente para o CVV no 188.
            </div>
            <div>
              <strong className="text-neutral-300 block mb-1">Nota Conceitual & Regulatória:</strong>
              Este aplicativo é um protótipo conceitual para demonstração de produto, economia de tokens e mecânicas de retenção visual (vermelho/dourado). A legislação brasileira (Lei 14.790/2023 - SPA/MF) veda o uso de moedas fictícias para camuflar valores em reais e restringe estímulos audiovisuais predatórios.
            </div>
          </div>

          <div className="text-center text-[10px] text-neutral-600 pt-4">
            © 2026 Lula Coins Casino · Conceito de Engenharia & Design de Produto · Todos os direitos reservados.
          </div>

        </div>
      </footer>

    </div>
  );
};

export default function App() {
  return (
    <CasinoProvider>
      <CasinoMain />
    </CasinoProvider>
  );
}
