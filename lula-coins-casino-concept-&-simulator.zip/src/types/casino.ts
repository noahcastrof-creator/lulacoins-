export type GameType = 'slots' | 'roulette' | 'blackjack' | 'live' | 'deposit' | 'withdraw' | 'vip' | 'rewards' | 'missions' | 'responsible' | 'whitepaper';

export interface UserProfile {
  id: string;
  name: string;
  cpf: string;
  email: string;
  balanceLC: number;
  totalDepositedBRL: number;
  totalWithdrawnBRL: number;
  vipTier: 'Bronze' | 'Prata' | 'Ouro' | 'Platina' | 'Diamante';
  vipXP: number;
  cashbackAvailableLC: number;
  lastDailyClaim: string | null;
  dailyStreak: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  rewardLC: number;
  progress: number;
  target: number;
  completed: boolean;
  claimed: boolean;
}

export interface Transaction {
  id: string;
  type: 'deposit_pix' | 'withdraw_pix' | 'game_win' | 'game_bet' | 'daily_bonus' | 'mission_reward' | 'cashback';
  amountLC: number;
  amountBRL?: number;
  feeBRL?: number;
  timestamp: string;
  status: 'concluido' | 'processando' | 'cancelado';
  description: string;
}

export interface ResponsibleGamingSettings {
  dailyDepositLimitBRL: number; // 0 = unlimited
  dailyLossLimitLC: number; // 0 = unlimited
  sessionTimeLimitMinutes: number; // e.g. 30
  sessionStartTime: number;
  isSelfExcluded: boolean;
  selfExclusionUntil: number | null;
  breakTimerActive: boolean;
}

export interface SlotSymbol {
  id: string;
  name: string;
  emoji: string;
  multiplier: number;
  color: string;
}
