import React from 'react';
import { Clock, ShieldAlert, AlertCircle, HeartHandshake } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';

export const ResponsibleModals: React.FC = () => {
  const {
    responsibleSettings,
    endSelfExclusionForTesting,
    triggerTimeWarning,
    dismissTimeWarning,
    sessionElapsedSeconds,
    setActiveTab,
  } = useCasino();

  const formatSessionTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} minutos`;
  };

  // 1. Full-screen Self-Exclusion Lockout Overlay
  if (responsibleSettings.isSelfExcluded) {
    const remainingMs = responsibleSettings.selfExclusionUntil ? Math.max(0, responsibleSettings.selfExclusionUntil - Date.now()) : 0;
    const remainingHours = Math.ceil(remainingMs / (1000 * 3600));

    return (
      <div className="fixed inset-0 z-50 bg-neutral-950/95 backdrop-blur-md flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-neutral-900 border-2 border-red-500 rounded-3xl p-6 sm:p-8 text-center space-y-5 shadow-2xl animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-full bg-red-950 border border-red-500/50 flex items-center justify-center mx-auto text-red-400">
            <ShieldAlert className="w-8 h-8" />
          </div>

          <div>
            <span className="text-xs uppercase font-extrabold text-red-400 tracking-wider">Proteção Ativa</span>
            <h2 className="text-xl font-cinzel font-black text-white mt-1">
              CONTA EM AUTOEXCLUSÃO
            </h2>
            <p className="text-xs text-neutral-300 mt-2 leading-relaxed">
              Você solicitou o bloqueio voluntário de apostas e depósitos. Este período é fundamental para descanso e reavaliação.
            </p>
          </div>

          <div className="p-3 bg-neutral-950 rounded-xl border border-neutral-800 text-xs">
            <span className="text-neutral-400 block">Tempo Restante de Bloqueio:</span>
            <span className="font-mono-num font-bold text-base text-amber-400">
              ~ {remainingHours} hora(s)
            </span>
          </div>

          <div className="text-[11px] text-neutral-400 p-3 bg-red-950/30 rounded-xl border border-red-950 space-y-1 text-left">
            <div className="font-semibold text-neutral-200">Precisa de apoio?</div>
            <div>Jogadores Anônimos: jogadoresanonimos.com.br</div>
            <div>CVV Apoio Emocional: Ligue 188 (24h)</div>
          </div>

          {/* Test Mode bypass button */}
          <button
            onClick={endSelfExclusionForTesting}
            className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs font-semibold rounded-xl border border-neutral-700 transition-colors"
          >
            [Modo Simulador: Encerrar Teste de Autoexclusão]
          </button>
        </div>
      </div>
    );
  }

  // 2. Periodic Session Time Alert Modal
  if (triggerTimeWarning) {
    return (
      <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="max-w-sm w-full bg-neutral-900 border border-amber-500/50 rounded-2xl p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
          <div className="w-12 h-12 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center mx-auto text-amber-400">
            <Clock className="w-6 h-6" />
          </div>

          <div>
            <span className="text-[10px] uppercase font-bold text-amber-400 tracking-wider">Lembrete de Sessão</span>
            <h3 className="text-lg font-cinzel font-bold text-neutral-100 mt-1">
              Hora de Fazer uma Pausa?
            </h3>
            <p className="text-xs text-neutral-300 mt-1 leading-relaxed">
              Você está jogando continuamente há <strong>{formatSessionTime(sessionElapsedSeconds)}</strong>. Pausas regulares mantêm as decisões lúcidas e o jogo saudável.
            </p>
          </div>

          <div className="flex flex-col gap-2 pt-2">
            <button
              onClick={() => {
                dismissTimeWarning();
                setActiveTab('responsible');
              }}
              className="w-full py-2.5 bg-gradient-to-r from-red-600 to-amber-500 text-neutral-950 font-bold text-xs rounded-xl shadow transition-all hover:brightness-110"
            >
              Configurar Limites / Fazer Pausa
            </button>
            <button
              onClick={dismissTimeWarning}
              className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs rounded-xl transition-colors"
            >
              Continuar Jogando
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
