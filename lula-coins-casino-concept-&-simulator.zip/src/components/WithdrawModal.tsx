import React, { useState } from 'react';
import { ArrowUpFromLine, AlertCircle, CheckCircle2, ShieldCheck, Sparkles, Coins } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';

export const WithdrawModal: React.FC = () => {
  const { user, withdrawPix, transactions } = useCasino();

  const [amountLC, setAmountLC] = useState<number>(2000);
  const [pixKey, setPixKey] = useState<string>('');
  const [pixKeyType, setPixKeyType] = useState<'cpf' | 'telefone' | 'email' | 'chave_aleatoria'>('cpf');
  const [resultMsg, setResultMsg] = useState<{ text: string; isError?: boolean } | null>(null);

  const feeRate = 0.05; // 5% taxa de troca reversa
  const grossBRL = amountLC / 100;
  const feeBRL = grossBRL * feeRate;
  const netBRL = Math.max(0, grossBRL - feeBRL);

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    setResultMsg(null);

    const res = withdrawPix(amountLC, pixKey || user.cpf);
    if (res.success) {
      setResultMsg({ text: res.message, isError: false });
    } else {
      setResultMsg({ text: res.message, isError: true });
    }
  };

  const setPreset = (lc: number) => {
    setAmountLC(Math.min(user.balanceLC, lc));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-neutral-950 via-red-950 to-neutral-950 border border-neutral-800 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Troca Reversa Transparente
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide text-neutral-100">
            RESGATE PIX (TROCA REVERSA)
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            Converta suas Lula Coins de volta em Reais diretamente na sua conta bancária via PIX.
          </p>
        </div>

        <div className="bg-neutral-900/90 px-4 py-3 rounded-xl border border-neutral-800 flex items-center gap-3">
          <Coins className="w-6 h-6 text-amber-400" />
          <div>
            <span className="text-[10px] text-neutral-400 uppercase font-semibold block">Disponível para Saque</span>
            <span className="text-lg font-bold text-amber-300 font-mono-num">
              {user.balanceLC.toLocaleString()} LC
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Withdrawal Form */}
        <div className="lg:col-span-7 p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-5">
          <form onSubmit={handleWithdraw} className="space-y-4">
            
            {/* Amount input */}
            <div>
              <div className="flex items-center justify-between mb-1.5 text-xs">
                <label className="text-neutral-300 font-semibold">Quantidade de Lula Coins para resgate:</label>
                <span className="text-neutral-400">Mínimo: 1.000 LC</span>
              </div>
              <input
                type="number"
                min="1000"
                max={user.balanceLC}
                step="100"
                value={amountLC}
                onChange={(e) => setAmountLC(Math.max(0, Number(e.target.value)))}
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2.5 text-base text-neutral-100 font-mono-num focus:outline-none focus:border-amber-400"
              />

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-2 mt-2">
                {[1000, 2500, 5000, 10000].map(val => (
                  <button
                    type="button"
                    key={val}
                    onClick={() => setPreset(val)}
                    className="px-2.5 py-1 text-xs bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg text-neutral-300 transition-colors"
                  >
                    {val.toLocaleString()} LC
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setPreset(user.balanceLC)}
                  className="px-2.5 py-1 text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg hover:bg-amber-500/30 font-semibold"
                >
                  Tudo
                </button>
              </div>
            </div>

            {/* PIX Key Type & Input */}
            <div className="space-y-2">
              <label className="text-xs text-neutral-300 font-semibold block">Tipo de Chave PIX de Destino:</label>
              <div className="grid grid-cols-4 gap-2 text-xs">
                {(['cpf', 'telefone', 'email', 'chave_aleatoria'] as const).map(t => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => setPixKeyType(t)}
                    className={`py-1.5 rounded-lg font-medium capitalize transition-colors ${
                      pixKeyType === t
                        ? 'bg-amber-400 text-neutral-950 font-bold'
                        : 'bg-neutral-900 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {t.replace('_', ' ')}
                  </button>
                ))}
              </div>

              <input
                type="text"
                required
                value={pixKey}
                onChange={(e) => setPixKey(e.target.value)}
                placeholder={
                  pixKeyType === 'cpf'
                    ? '000.000.000-00'
                    : pixKeyType === 'telefone'
                    ? '(11) 90000-0000'
                    : pixKeyType === 'email'
                    ? 'seu-email@dominio.com'
                    : 'Chave Aleatória UUID'
                }
                className="w-full bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={amountLC < 1000 || user.balanceLC < amountLC}
              className={`w-full py-3.5 px-4 rounded-xl font-cinzel font-black text-sm tracking-wider uppercase transition-all shadow-md flex items-center justify-center gap-2 ${
                amountLC < 1000 || user.balanceLC < amountLC
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-500 text-white hover:brightness-110 shadow-emerald-500/20'
              }`}
            >
              <ArrowUpFromLine className="w-4 h-4 stroke-[2.5]" />
              <span>Solicitar Resgate PIX (Líquido: R$ {netBRL.toFixed(2)})</span>
            </button>

            {/* Notification message */}
            {resultMsg && (
              <div
                className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                  resultMsg.isError
                    ? 'bg-red-950/80 border border-red-500/50 text-red-200'
                    : 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-200'
                }`}
              >
                {resultMsg.isError ? (
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                )}
                <span>{resultMsg.text}</span>
              </div>
            )}
          </form>
        </div>

        {/* Right: Detailed Fee Breakdown & Policy */}
        <div className="lg:col-span-5 p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider">
            Detalhamento da Troca Reversa
          </h3>

          <div className="space-y-3 p-4 bg-neutral-900/80 rounded-xl border border-neutral-800 text-xs">
            <div className="flex justify-between text-neutral-400">
              <span>Lula Coins Convertidas:</span>
              <span className="font-mono-num text-neutral-200">{amountLC.toLocaleString()} LC</span>
            </div>
            <div className="flex justify-between text-neutral-400">
              <span>Valor Bruto (100 LC = R$ 1):</span>
              <span className="font-mono-num text-neutral-200">R$ {grossBRL.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-red-400">
              <span>Taxa de Processamento (5%):</span>
              <span className="font-mono-num font-semibold">- R$ {feeBRL.toFixed(2)}</span>
            </div>
            <div className="pt-2 border-t border-neutral-800 flex justify-between text-sm font-bold">
              <span className="text-emerald-400">Você Recebe no PIX:</span>
              <span className="text-emerald-300 font-mono-num text-base">R$ {netBRL.toFixed(2)}</span>
            </div>
          </div>

          <div className="text-[11px] text-neutral-400 space-y-2 leading-relaxed">
            <p>
              🔒 <strong>Regra de Liquidez:</strong> A taxa de 5% é retida para custear os custos operacionais da infraestrutura PIX e alimentar o fundo de garantia de prêmios da comunidade.
            </p>
            <p>
              ⏱️ <strong>Tempo de Processamento:</strong> Pagamentos automáticos processados em até 5 minutos via chave PIX cadastrada.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};
