import React from 'react';
import { Coins, Volume2, VolumeX, ShieldAlert, ArrowDownToLine, ArrowUpFromLine, Award, Sparkles, BookOpen } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { GameType } from '../types/casino';

export const Navbar: React.FC = () => {
  const {
    user,
    activeTab,
    setActiveTab,
    isMuted,
    toggleMute,
    sessionElapsedSeconds,
    responsibleSettings,
  } = useCasino();

  const formatSessionTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs < 10 ? '0' : ''}${secs}s`;
  };

  const navItems: { id: GameType; label: string }[] = [
    { id: 'slots', label: 'Caça-Níquel' },
    { id: 'roulette', label: 'Roleta' },
    { id: 'blackjack', label: 'Blackjack' },
    { id: 'live', label: 'Ao Vivo' },
    { id: 'vip', label: 'VIP & Loja' },
    { id: 'missions', label: 'Missões' },
    { id: 'whitepaper', label: 'Tokenomics' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-neutral-950/95 backdrop-blur-md border-b border-red-950/60 shadow-lg shadow-red-950/20">
      {/* Top Bar Contract (1-row 3-zones) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand wordmark with official Lula Coins logo */}
        <button
          onClick={() => setActiveTab('slots')}
          className="flex items-center gap-3 text-left shrink-0 group focus:outline-none"
        >
          <img
            src="/src/assets/images/lula_coins_logo_1792135128596.jpg"
            alt="Lula Coins Official Emblem"
            className="w-10 h-10 rounded-full object-cover border-2 border-amber-400 shadow-lg shadow-amber-500/30 group-hover:scale-105 transition-transform"
          />
          <div className="flex flex-col">
            <span className="font-cinzel font-black text-lg tracking-wider text-neutral-100 flex items-center gap-1.5 leading-none">
              LULA <span className="gold-gradient-text">COINS</span>
            </span>
            <span className="text-[10px] text-amber-400 font-semibold tracking-widest uppercase">
              Cassino Oficial
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-5 text-sm font-medium">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`whitespace-nowrap transition-colors py-1 ${
                activeTab === item.id
                  ? 'text-amber-400 font-semibold border-b-2 border-amber-400'
                  : 'text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Balance & Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Sound Toggle */}
          <button
            onClick={toggleMute}
            aria-label={isMuted ? 'Ativar som' : 'Silenciar som'}
            className="p-2 text-neutral-400 hover:text-amber-400 hover:bg-neutral-900 rounded-lg transition-colors"
            title={isMuted ? 'Ativar Efeitos Sonoros' : 'Silenciar'}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5 text-amber-400" />}
          </button>

          {/* Balance display */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-neutral-900/90 border border-amber-500/30 rounded-lg shadow-inner">
            <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider leading-none">Saldo LC</span>
              <span className="text-sm font-bold text-amber-300 font-mono-num leading-tight">
                {user.balanceLC.toLocaleString()} LC
              </span>
            </div>
          </div>

          {/* Quick Deposit PIX CTA */}
          <button
            onClick={() => setActiveTab('deposit')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-neutral-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 rounded-lg hover:from-amber-300 hover:to-yellow-400 shadow-md shadow-amber-500/25 transition-all transform hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap shrink-0"
          >
            <ArrowDownToLine className="w-4 h-4 text-neutral-950 stroke-[2.5]" />
            <span>Recarregar PIX</span>
          </button>

          {/* Quick Saque Button */}
          <button
            onClick={() => setActiveTab('withdraw')}
            className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-neutral-200 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-amber-500/50 rounded-lg transition-all whitespace-nowrap shrink-0"
          >
            <ArrowUpFromLine className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sacar</span>
          </button>

          {/* Responsible Gaming Quick Icon */}
          <button
            onClick={() => setActiveTab('responsible')}
            className={`p-2 rounded-lg border transition-all ${
              responsibleSettings.isSelfExcluded
                ? 'bg-red-950/80 border-red-500 text-red-400'
                : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-red-400 hover:border-red-900'
            }`}
            title="Jogo Responsável & Proteções"
          >
            <ShieldAlert className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Sub-bar for mobile navigation & Session / VIP indicator */}
      <div className="bg-neutral-900/60 border-t border-neutral-800/80 px-4 py-1.5 text-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 overflow-x-auto no-scrollbar">
          
          <div className="flex items-center gap-4 shrink-0 text-neutral-400">
            {/* VIP Status */}
            <button
              onClick={() => setActiveTab('vip')}
              className="flex items-center gap-1.5 hover:text-amber-300 transition-colors"
            >
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span>Nível VIP: <strong className="text-amber-400 font-semibold">{user.vipTier}</strong></span>
              <span className="text-neutral-500">({user.vipXP} XP)</span>
            </button>

            <span className="text-neutral-700 hidden sm:inline">|</span>

            {/* Session Timer */}
            <div className="hidden sm:flex items-center gap-1 text-neutral-400">
              <span>Sessão:</span>
              <span className="font-mono-num text-neutral-300">{formatSessionTime(sessionElapsedSeconds)}</span>
              {responsibleSettings.sessionTimeLimitMinutes > 0 && (
                <span className="text-neutral-500">/ {responsibleSettings.sessionTimeLimitMinutes}m máx</span>
              )}
            </div>

            <span className="text-neutral-700 hidden md:inline">|</span>

            {/* Instant PIX status */}
            <div className="hidden md:flex items-center gap-1.5 text-neutral-400">
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> PIX Ativo
              </span>
              <span className="text-neutral-500">· Crédito instantâneo em 30 segundos</span>
            </div>
          </div>

          {/* Quick links for Mobile */}
          <div className="flex lg:hidden items-center gap-2 shrink-0">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-2 py-0.5 rounded text-xs whitespace-nowrap transition-colors ${
                  activeTab === item.id
                    ? 'bg-amber-500/20 text-amber-400 font-semibold'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

        </div>
      </div>
    </header>
  );
};
