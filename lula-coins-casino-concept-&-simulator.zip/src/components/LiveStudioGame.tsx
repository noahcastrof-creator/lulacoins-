import React, { useState, useEffect } from 'react';
import { Radio, Users, MessageSquare, Send, Sparkles, Volume2, ShieldCheck, Heart } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { sounds } from '../services/soundEffects';

interface ChatMessage {
  id: string;
  sender: string;
  badge?: string;
  text: string;
  time: string;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  { id: '1', sender: 'Rodrigo_SP', badge: 'VIP Ouro', text: 'Alguém apostando no 7 hoje?', time: '23:45' },
  { id: '2', sender: 'Carla_RJ', badge: 'VIP Platina', text: 'Bora vermelho que tá quente!', time: '23:46' },
  { id: '3', sender: 'Lucas_Bet', text: 'Acabei de fazer meu primeiro PIX pro CPF, caiu em 30s!', time: '23:46' },
  { id: '4', sender: 'Marcos_Sul', badge: 'VIP Diamante', text: 'Crupiê tá abençoando hoje galera kkk', time: '23:47' },
];

export const LiveStudioGame: React.FC = () => {
  const { user, placeBet, registerWin, checkSelfExclusion } = useCasino();

  const [countdown, setCountdown] = useState<number>(12);
  const [roundPhase, setRoundPhase] = useState<'betting' | 'spinning' | 'payout'>('betting');
  const [selectedBetType, setSelectedBetType] = useState<'red' | 'black' | 'gold'>('red');
  const [betAmount, setBetAmount] = useState<number>(100);
  const [currentRoundWinner, setCurrentRoundWinner] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_MESSAGES);
  const [userChatInput, setUserChatInput] = useState<string>('');
  const [likesCount, setLikesCount] = useState<number>(342);

  // Live timer countdown loop
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Switch phases
          if (roundPhase === 'betting') {
            setRoundPhase('spinning');
            sounds.playSpinStart();
            return 5; // 5 seconds spinning
          } else if (roundPhase === 'spinning') {
            // Determine result: In this concept, player never wins, only spends
            let outcome: 'red' | 'black' | 'gold' = 'black';
            if (selectedBetType === 'red') {
              outcome = 'black';
            } else if (selectedBetType === 'black') {
              outcome = 'red';
            } else {
              outcome = Math.random() < 0.5 ? 'red' : 'black';
            }

            setCurrentRoundWinner(outcome);
            setRoundPhase('payout');
            sounds.playReelStop(1.2);
            return 4; // 4 seconds payout screen
          } else {
            // Reset to betting
            setRoundPhase('betting');
            setCurrentRoundWinner(null);
            return 15;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [roundPhase, selectedBetType]);

  // Handle outcome payout: always zero win for the player
  useEffect(() => {
    if (roundPhase === 'payout' && currentRoundWinner) {
      // Player never wins Lula Coins in this concept
      sounds.playReelStop(0.5);
    }
  }, [roundPhase, currentRoundWinner]);

  const handlePlaceLiveBet = () => {
    if (roundPhase !== 'betting') return;
    if (checkSelfExclusion()) return;
    if (user.balanceLC < betAmount) {
      sounds.playReelStop(0.5);
      return;
    }

    const ok = placeBet('live_roulette', betAmount);
    if (ok) {
      sounds.playChipSound();
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userChatInput.trim()) return;

    const newMsg: ChatMessage = {
      id: 'usr_' + Date.now(),
      sender: user.name,
      badge: `VIP ${user.vipTier}`,
      text: userChatInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev.slice(-15), newMsg]);
    setUserChatInput('');
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      
      {/* Studio Header */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-red-600/90 text-white font-black text-[10px] tracking-wider uppercase shadow">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" /> AO VIVO HD
            </span>
            <span className="text-xs text-neutral-400">Estúdio Central São Paulo</span>
          </div>
          <h1 className="text-2xl font-cinzel font-black tracking-wide gold-gradient-text">
            MESA VIP LULA GOLD AO VIVO
          </h1>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5 bg-neutral-900/90 px-3 py-1.5 rounded-lg border border-neutral-800">
            <Users className="w-4 h-4 text-amber-400" />
            <span className="text-neutral-300 font-bold font-mono-num">1.482 jogadores</span>
          </div>
          <button
            onClick={() => setLikesCount((c) => c + 1)}
            className="flex items-center gap-1.5 bg-red-950/60 hover:bg-red-900/60 text-red-300 px-3 py-1.5 rounded-lg border border-red-800/60 transition-all"
          >
            <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            <span className="font-mono-num">{likesCount}</span>
          </button>
        </div>
      </div>

      {/* Main Studio View Split (Live Broadcast + Live Chat) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Video Broadcast Simulated Viewport */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative aspect-video rounded-3xl bg-neutral-950 border-2 border-red-900/60 shadow-2xl overflow-hidden flex flex-col justify-between p-6">
            
            {/* Cinematic Live Studio Backdrop */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_#450a0a_0%,_#171717_60%,_#050505_100%)] opacity-90 pointer-events-none" />
            
            {/* Top Stream Overlay */}
            <div className="relative z-10 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-amber-500 flex items-center justify-center font-bold text-xs text-neutral-950 shadow">
                  LC
                </div>
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">Crupiê Mariana</span>
                  <span className="text-[10px] text-amber-400">Mesa Oficial 01</span>
                </div>
              </div>

              {/* Countdown Pill */}
              <div className="flex items-center gap-2 bg-neutral-950/90 border border-amber-500/50 px-4 py-1.5 rounded-xl shadow-lg">
                <span className="text-xs text-neutral-400 font-semibold uppercase">
                  {roundPhase === 'betting' ? 'Apostas Fecham Em' : roundPhase === 'spinning' ? 'Girando' : 'Resultado'}
                </span>
                <span className={`text-base font-black font-mono-num ${countdown <= 3 ? 'text-red-400 animate-ping' : 'text-amber-400'}`}>
                  {countdown}s
                </span>
              </div>
            </div>

            {/* Center Stage Presentation */}
            <div className="relative z-10 flex flex-col items-center justify-center text-center my-auto">
              {roundPhase === 'betting' && (
                <div className="p-4 rounded-2xl bg-neutral-900/80 border border-amber-500/40 backdrop-blur-md max-w-sm animate-in zoom-in-95">
                  <span className="text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                    Façam Suas Apostas
                  </span>
                  <p className="text-sm font-semibold text-neutral-200 mt-1">
                    Escolha Vermelho (2x), Preto (2x) ou Símbolo de Ouro (14x)
                  </p>
                </div>
              )}

              {roundPhase === 'spinning' && (
                <div className="flex flex-col items-center animate-pulse">
                  <div className="w-24 h-24 rounded-full border-4 border-amber-400 border-t-red-600 animate-spin flex items-center justify-center bg-neutral-900 shadow-2xl">
                    <Sparkles className="w-8 h-8 text-amber-400" />
                  </div>
                  <span className="text-sm font-bold text-amber-300 mt-3 font-cinzel">
                    A roleta ao vivo está desacelerando...
                  </span>
                </div>
              )}

              {roundPhase === 'payout' && currentRoundWinner && (
                <div className="p-6 rounded-2xl bg-gradient-to-r from-red-600 via-amber-500 to-red-600 border-2 border-white shadow-2xl animate-in zoom-in-90 duration-300">
                  <span className="text-xs uppercase font-black text-neutral-950 tracking-widest block">
                    Resultado da Rodada
                  </span>
                  <div className="text-3xl font-black font-cinzel text-neutral-950 mt-1 uppercase">
                    {currentRoundWinner === 'red' ? '🔴 VERMELHO' : currentRoundWinner === 'black' ? '⚫ PRETO' : '👑 OURO (14x)'}
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Stream Status */}
            <div className="relative z-10 flex items-center justify-between text-xs text-neutral-400">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>RNG Certificado & Transmissão Criptografada</span>
              </div>
              <span className="font-mono text-[11px] text-neutral-500">LATENCY: 0.2s</span>
            </div>
          </div>

          {/* Quick Action Betting Controls */}
          <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-400 font-bold uppercase">Opção:</span>
              <button
                disabled={roundPhase !== 'betting'}
                onClick={() => setSelectedBetType('red')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedBetType === 'red'
                    ? 'bg-red-600 text-white border-2 border-white shadow-lg shadow-red-600/40'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-700'
                }`}
              >
                🔴 Vermelho (2x)
              </button>
              <button
                disabled={roundPhase !== 'betting'}
                onClick={() => setSelectedBetType('black')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedBetType === 'black'
                    ? 'bg-neutral-800 text-white border-2 border-white shadow-lg'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-700'
                }`}
              >
                ⚫ Preto (2x)
              </button>
              <button
                disabled={roundPhase !== 'betting'}
                onClick={() => setSelectedBetType('gold')}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedBetType === 'gold'
                    ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-neutral-950 border-2 border-white shadow-lg shadow-amber-400/40'
                    : 'bg-neutral-900 text-amber-400 hover:text-amber-200 border border-neutral-700'
                }`}
              >
                👑 Ouro (14x)
              </button>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 bg-neutral-900 p-1 rounded-xl border border-neutral-800">
                {[50, 100, 250, 500].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setBetAmount(amt)}
                    className={`px-2.5 py-1 text-xs font-bold rounded-lg ${
                      betAmount === amt ? 'bg-amber-400 text-neutral-950' : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {amt}
                  </button>
                ))}
              </div>

              <button
                disabled={roundPhase !== 'betting' || user.balanceLC < betAmount}
                onClick={handlePlaceLiveBet}
                className={`px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider font-cinzel transition-all shadow-md ${
                  roundPhase !== 'betting' || user.balanceLC < betAmount
                    ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-neutral-950 hover:brightness-110'
                }`}
              >
                Confirmar ({betAmount} LC)
              </button>
            </div>
          </div>
        </div>

        {/* Right: Live Chat Feed */}
        <div className="lg:col-span-4 p-5 rounded-3xl bg-neutral-950 border border-neutral-800 shadow-xl flex flex-col justify-between h-[480px]">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <h3 className="text-sm font-bold text-neutral-200 flex items-center gap-1.5">
                <MessageSquare className="w-4 h-4 text-amber-400" />
                <span>Chat dos Jogadores</span>
              </h3>
              <span className="text-[11px] text-neutral-400">Moderado</span>
            </div>

            {/* Chat List */}
            <div className="space-y-3 py-3 overflow-y-auto max-h-[340px] pr-1">
              {chatMessages.map((msg) => (
                <div key={msg.id} className="text-xs bg-neutral-900/60 p-2.5 rounded-xl border border-neutral-800/80">
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="font-bold text-neutral-200 flex items-center gap-1.5 truncate">
                      {msg.sender}
                      {msg.badge && (
                        <span className="text-[9px] font-extrabold text-amber-400 bg-amber-950/80 px-1.5 py-0.2 rounded border border-amber-500/20">
                          {msg.badge}
                        </span>
                      )}
                    </span>
                    <span className="text-[10px] text-neutral-500 font-mono-num shrink-0">{msg.time}</span>
                  </div>
                  <p className="text-neutral-300 break-words leading-relaxed">{msg.text}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Chat Form */}
          <form onSubmit={handleSendChat} className="pt-2 border-t border-neutral-800 flex gap-2">
            <input
              type="text"
              value={userChatInput}
              onChange={(e) => setUserChatInput(e.target.value)}
              placeholder="Digite no chat ao vivo..."
              className="flex-1 bg-neutral-900 border border-neutral-700 rounded-xl px-3 py-2 text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              className="p-2 bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-xl transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
