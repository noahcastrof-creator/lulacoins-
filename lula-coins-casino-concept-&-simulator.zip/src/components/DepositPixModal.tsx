import React, { useState } from 'react';
import { Copy, Check, QrCode, Sparkles, ShieldCheck, ArrowDownToLine, AlertCircle } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';

const PIX_CPF = '551.908.838-17';

const PACKAGES = [
  { brl: 20, lc: 2000, bonus: 200, badge: 'Popular', label: 'Iniciante' },
  { brl: 50, lc: 5500, bonus: 500, badge: '+10% Bônus', label: 'Mais Escolhido' },
  { brl: 100, lc: 12000, bonus: 2000, badge: '+20% VIP', label: 'Alta Vantagem' },
  { brl: 250, lc: 32500, bonus: 7500, badge: '+30% Bônus', label: 'High Roller' },
];

export const DepositPixModal: React.FC = () => {
  const { depositPix, responsibleSettings } = useCasino();

  const [selectedPkg, setSelectedPkg] = useState(PACKAGES[1]);
  const [customBrl, setCustomBrl] = useState<string>('');
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  const activeAmountBRL = customBrl && Number(customBrl) > 0 ? Number(customBrl) : selectedPkg.brl;

  // Simulated EMV PIX Copia e Cola string
  const pixCopyPastePayload = `00020126580014br.gov.bcb.pix0114${PIX_CPF.replace(/\D/g, '')}520400005303986540${activeAmountBRL.toFixed(2)}5802BR5916LULA COINS CASINO6009SAO PAULO62070503***6304ABCD`;

  const copyCpf = () => {
    navigator.clipboard.writeText(PIX_CPF);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const copyPixCode = () => {
    navigator.clipboard.writeText(pixCopyPastePayload);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleSimulatePayment = () => {
    setStatusMessage(null);
    const result = depositPix(activeAmountBRL);
    if (result.success) {
      setStatusMessage({ text: result.message, isError: false });
    } else {
      setStatusMessage({ text: result.message, isError: true });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src="/src/assets/images/lula_coins_logo_1792135128596.jpg"
            alt="Lula Coins"
            className="w-14 h-14 rounded-full object-cover border-2 border-amber-400 shadow-lg shadow-amber-500/30 shrink-0"
          />
          <div>
            <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5 mb-1">
              <Sparkles className="w-3.5 h-3.5" /> Crédito Instantâneo 24/7
            </span>
            <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
              RECARREGAR LULA COINS VIA PIX
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300">
              Cotação base: R$ 1,00 = 100 Lula Coins (+ Bônus promocional de recarga).
            </p>
          </div>
        </div>

        {responsibleSettings.dailyDepositLimitBRL > 0 && (
          <div className="bg-neutral-950/80 px-4 py-2 rounded-xl border border-neutral-800 text-xs">
            <span className="text-neutral-400 block">Seu Limite Diário Configurado:</span>
            <span className="font-bold text-amber-300 font-mono-num">
              R$ {responsibleSettings.dailyDepositLimitBRL.toFixed(2)}
            </span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Package Selector */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
            <h2 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <span>1. Escolha o Pacote de Moedas</span>
            </h2>

            <div className="grid grid-cols-2 gap-3">
              {PACKAGES.map((pkg) => {
                const isSelected = selectedPkg.brl === pkg.brl && !customBrl;
                return (
                  <button
                    key={pkg.brl}
                    onClick={() => {
                      setSelectedPkg(pkg);
                      setCustomBrl('');
                    }}
                    className={`p-4 rounded-xl text-left border-2 transition-all relative ${
                      isSelected
                        ? 'bg-gradient-to-br from-red-950/80 to-amber-950/60 border-amber-400 shadow-lg shadow-amber-500/20'
                        : 'bg-neutral-900/80 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-neutral-400">{pkg.label}</span>
                      <span className="text-[10px] font-black text-amber-400 bg-amber-950 px-1.5 py-0.5 rounded border border-amber-500/30">
                        {pkg.badge}
                      </span>
                    </div>

                    <div className="text-xl font-black font-cinzel text-neutral-100 font-mono-num">
                      R$ {pkg.brl},00
                    </div>

                    <div className="text-xs text-amber-300 font-bold mt-1">
                      {(pkg.lc + pkg.bonus).toLocaleString()} LC
                    </div>
                    <div className="text-[10px] text-neutral-400">
                      ({pkg.lc.toLocaleString()} + {pkg.bonus.toLocaleString()} bônus)
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Custom Amount */}
            <div className="pt-2">
              <label className="text-xs text-neutral-400 block mb-1">Ou digite outro valor em Reais (R$):</label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-xs text-neutral-500 font-bold">R$</span>
                <input
                  type="number"
                  min="5"
                  max="10000"
                  value={customBrl}
                  onChange={(e) => setCustomBrl(e.target.value)}
                  placeholder="Ex: 80"
                  className="w-full bg-neutral-900 border border-neutral-700 rounded-xl pl-9 pr-4 py-2 text-sm text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Payment Instructions (PIX CPF & QR / Copia e Cola) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 bg-neutral-950 border border-amber-500/30 rounded-2xl shadow-xl space-y-5">
            
            <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center gap-2">
              <span>2. Dados de Pagamento PIX</span>
            </h2>

            {/* QR Code Simulation Box */}
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-inner max-w-[200px] mx-auto">
              <div className="w-36 h-36 border-4 border-neutral-950 p-2 flex flex-col items-center justify-center text-neutral-950 text-center">
                <QrCode className="w-24 h-24 text-neutral-950" />
                <span className="text-[9px] font-black uppercase mt-1 tracking-tighter">PIX R$ {activeAmountBRL.toFixed(2)}</span>
              </div>
            </div>

            {/* Official CPF Key Box */}
            <div className="bg-neutral-900/90 p-3.5 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-[11px] text-neutral-400 font-semibold block uppercase">Chave PIX (CPF):</span>
              <div className="flex items-center justify-between gap-2">
                <code className="text-base font-mono font-bold text-amber-300">
                  {PIX_CPF}
                </code>
                <button
                  onClick={copyCpf}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg transition-colors shrink-0"
                >
                  {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey ? 'Copiado!' : 'Copiar'}</span>
                </button>
              </div>
            </div>

            {/* Copia e Cola */}
            <div className="bg-neutral-900/90 p-3.5 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-[11px] text-neutral-400 font-semibold block uppercase">Código Copia e Cola:</span>
              <div className="flex items-center justify-between gap-2">
                <input
                  type="text"
                  readOnly
                  value={pixCopyPastePayload}
                  className="bg-transparent text-xs text-neutral-400 truncate w-full outline-none font-mono"
                />
                <button
                  onClick={copyPixCode}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold bg-amber-400 hover:bg-amber-300 text-neutral-950 rounded-lg transition-colors shrink-0 font-bold"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-800" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copiado!' : 'Copiar'}</span>
                </button>
              </div>
            </div>

            {/* Instant Sandbox Confirmation Button */}
            <button
              onClick={handleSimulatePayment}
              className="w-full py-3.5 px-4 rounded-xl font-cinzel font-black text-sm tracking-wider uppercase text-neutral-950 bg-gradient-to-r from-emerald-500 via-amber-400 to-emerald-500 hover:brightness-110 shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
            >
              <ArrowDownToLine className="w-4 h-4 stroke-[2.5]" />
              <span>Simular Confirmação PIX (R$ {activeAmountBRL.toFixed(2)})</span>
            </button>

            {/* Status Alert */}
            {statusMessage && (
              <div
                className={`p-3 rounded-xl text-xs flex items-start gap-2 ${
                  statusMessage.isError
                    ? 'bg-red-950/80 border border-red-500/50 text-red-200'
                    : 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-200'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{statusMessage.text}</span>
              </div>
            )}

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-500 text-center">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Compensação automática e segura via Banco Central do Brasil</span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
