import React, { useState } from 'react';
import { Calendar, CheckCircle2, RotateCw, Gift, Sparkles, Award, Coins } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { sounds } from '../services/soundEffects';

const WHEEL_PRIZES = [
  { label: '250 LC', val: 250, color: 'bg-red-800' },
  { label: '500 LC', val: 500, color: 'bg-amber-600' },
  { label: '100 LC', val: 100, color: 'bg-neutral-800' },
  { label: '1.000 LC', val: 1000, color: 'bg-amber-500' },
  { label: '300 LC', val: 300, color: 'bg-red-700' },
  { label: '2.500 LC ★', val: 2500, color: 'bg-yellow-400 text-neutral-950 font-black' },
  { label: '150 LC', val: 150, color: 'bg-neutral-800' },
  { label: '750 LC', val: 750, color: 'bg-amber-700' },
];

export const DailyMissions: React.FC = () => {
  const { user, missions, claimDailyReward, claimMissionReward, registerWin, triggerConfetti } = useCasino();

  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [isSpinningWheel, setIsSpinningWheel] = useState<boolean>(false);
  const [wheelResult, setWheelResult] = useState<string | null>(null);
  const [claimedTodayWheel, setClaimedTodayWheel] = useState<boolean>(false);

  const todayStr = new Date().toDateString();
  const alreadyClaimedStreak = user.lastDailyClaim === todayStr;

  const handleClaimStreak = () => {
    claimDailyReward();
  };

  const spinDailyWheel = () => {
    if (isSpinningWheel || claimedTodayWheel) return;

    setIsSpinningWheel(true);
    setWheelResult(null);
    sounds.playSpinStart();

    const selectedPrizeIndex = Math.floor(Math.random() * WHEEL_PRIZES.length);
    const degreesPerSlice = 360 / WHEEL_PRIZES.length;
    const targetDeg = 1800 + (selectedPrizeIndex * degreesPerSlice);

    setWheelRotation(prev => prev + targetDeg);

    setTimeout(() => {
      setIsSpinningWheel(false);
      setClaimedTodayWheel(true);
      const prize = WHEEL_PRIZES[selectedPrizeIndex];
      setWheelResult(`Você ganhou ${prize.label} na Roda da Fortuna!`);
      registerWin('Roda da Fortuna Diária', 0, prize.val, prize.val >= 1000);
      sounds.playJackpotFanfare();
      triggerConfetti();
    }, 2500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Ganhe Moedas Sem Depositar
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
            BÔNUS DIÁRIOS & MISSÕES
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            Mantenha sua sequência diária ativa e complete desafios para encher seu saldo de Lula Coins!
          </p>
        </div>

        {/* Daily streak indicator */}
        <div className="bg-neutral-950/90 border border-amber-500/40 px-5 py-3 rounded-xl flex items-center gap-3">
          <Calendar className="w-6 h-6 text-amber-400" />
          <div>
            <span className="text-[10px] text-neutral-400 uppercase font-bold block">Sequência Atual</span>
            <span className="text-lg font-black text-amber-300 font-mono-num">
              {user.dailyStreak} Dias Consecutivos
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Daily Streak Claim & Wheel */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Daily Streak Card */}
          <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <Gift className="w-4 h-4 text-amber-400" />
              <span>Bônus de Login Diário</span>
            </h3>

            <p className="text-xs text-neutral-400">
              Quanto maior sua sequência, maior o prêmio! Hoje o bônus vale <strong>{500 + user.dailyStreak * 150} LC</strong>.
            </p>

            <button
              disabled={alreadyClaimedStreak}
              onClick={handleClaimStreak}
              className={`w-full py-3 px-4 rounded-xl font-cinzel font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                alreadyClaimedStreak
                  ? 'bg-neutral-800 text-neutral-500 border border-neutral-700 cursor-not-allowed'
                  : 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-neutral-950 hover:brightness-110 shadow-lg shadow-amber-500/20'
              }`}
            >
              {alreadyClaimedStreak ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>Já Resgatado Hoje (Volte Amanhã)</span>
                </>
              ) : (
                <>
                  <Coins className="w-4 h-4" />
                  <span>Resgatar Bônus de Hoje (+{500 + user.dailyStreak * 150} LC)</span>
                </>
              )}
            </button>
          </div>

          {/* Interactive Wheel of Fortune */}
          <div className="p-6 bg-neutral-950 border border-amber-500/30 rounded-2xl shadow-xl flex flex-col items-center text-center space-y-4">
            <div>
              <h3 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center justify-center gap-1.5">
                <RotateCw className="w-4 h-4" />
                <span>Roda da Fortuna Lula Coins</span>
              </h3>
              <span className="text-[11px] text-neutral-400">1 giro gratuito a cada 24 horas</span>
            </div>

            {/* Simulated Wheel Disc */}
            <div className="relative w-48 h-48 flex items-center justify-center my-2">
              <div
                className="w-44 h-44 rounded-full border-4 border-amber-400 transition-transform duration-[2500ms] ease-out shadow-2xl relative overflow-hidden flex items-center justify-center bg-gradient-to-tr from-red-950 via-amber-900 to-neutral-950"
                style={{ transform: `rotate(${wheelRotation}deg)` }}
              >
                <div className="absolute inset-0 bg-[conic-gradient(from_0deg,_#dc2626_0deg_45deg,_#b45309_45deg_90deg,_#171717_90deg_135deg,_#eab308_135deg_180deg,_#991b1b_180deg_225deg,_#facc15_225deg_270deg,_#262626_270deg_315deg,_#d97706_315deg_360deg)] opacity-80" />
                
                <div className="relative z-10 w-14 h-14 rounded-full bg-neutral-950 border-2 border-amber-400 flex items-center justify-center font-cinzel font-black text-amber-400 text-xs shadow-md">
                  GIRAR
                </div>
              </div>

              {/* Top Pointer */}
              <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-4 h-4 bg-yellow-300 border border-neutral-950 rotate-45 z-20 shadow-md" />
            </div>

            {wheelResult && (
              <div className="text-xs font-bold text-amber-300 bg-neutral-900 border border-amber-500/40 p-2.5 rounded-xl animate-in zoom-in-95 w-full">
                {wheelResult}
              </div>
            )}

            <button
              disabled={isSpinningWheel || claimedTodayWheel}
              onClick={spinDailyWheel}
              className={`w-full py-2.5 px-4 rounded-xl font-cinzel font-black text-xs uppercase tracking-wider transition-all ${
                claimedTodayWheel
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : isSpinningWheel
                  ? 'bg-amber-600 text-neutral-950 animate-pulse'
                  : 'bg-gradient-to-r from-red-600 to-amber-500 text-neutral-950 hover:brightness-110'
              }`}
            >
              {claimedTodayWheel ? 'Giro Realizado' : isSpinningWheel ? 'Girando...' : 'Girar Roda da Fortuna'}
            </button>
          </div>

        </div>

        {/* Right: Daily Missions List */}
        <div className="lg:col-span-7 p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
            <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-400" />
              <span>Missões do Dia</span>
            </h3>
            <span className="text-xs text-neutral-400 font-mono-num">
              {missions.filter(m => m.completed).length}/{missions.length} Concluídas
            </span>
          </div>

          <div className="space-y-3">
            {missions.map((mission) => {
              const pct = Math.min(100, Math.round((mission.progress / mission.target) * 100));

              return (
                <div
                  key={mission.id}
                  className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-all"
                >
                  <div className="space-y-1.5 flex-1 w-full">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-100">{mission.title}</span>
                      <span className="text-xs font-mono-num font-extrabold text-amber-400">
                        +{mission.rewardLC.toLocaleString()} LC
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-400 leading-snug">{mission.description}</p>

                    {/* Progress */}
                    <div className="flex items-center gap-2 pt-1">
                      <div className="flex-1 bg-neutral-950 h-2 rounded-full overflow-hidden border border-neutral-800">
                        <div
                          className="bg-gradient-to-r from-amber-500 to-yellow-400 h-full rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-mono-num text-neutral-400 font-semibold shrink-0">
                        {mission.progress}/{mission.target}
                      </span>
                    </div>
                  </div>

                  <div className="sm:shrink-0 w-full sm:w-auto">
                    <button
                      disabled={!mission.completed || mission.claimed}
                      onClick={() => claimMissionReward(mission.id)}
                      className={`w-full sm:w-auto px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                        mission.claimed
                          ? 'bg-neutral-800 text-neutral-500 cursor-default'
                          : mission.completed
                          ? 'bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-md shadow-amber-400/20 animate-pulse'
                          : 'bg-neutral-800/80 text-neutral-500 cursor-not-allowed'
                      }`}
                    >
                      {mission.claimed ? 'Resgatado ✓' : mission.completed ? 'Coletar Recompensa' : 'Em Progresso'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

    </div>
  );
};
