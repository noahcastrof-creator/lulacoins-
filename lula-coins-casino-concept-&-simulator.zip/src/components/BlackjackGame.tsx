import React, { useState } from 'react';
import { Sparkles, Play, ShieldAlert, Award, Plus, Hand, ArrowDown } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { sounds } from '../services/soundEffects';

interface Card {
  suit: '♠' | '♥' | '♦' | '♣';
  value: string;
  weight: number;
}

const SUITS: ('♠' | '♥' | '♦' | '♣')[] = ['♠', '♥', '♦', '♣'];
const VALUES = [
  { val: '2', weight: 2 },
  { val: '3', weight: 3 },
  { val: '4', weight: 4 },
  { val: '5', weight: 5 },
  { val: '6', weight: 6 },
  { val: '7', weight: 7 },
  { val: '8', weight: 8 },
  { val: '9', weight: 9 },
  { val: '10', weight: 10 },
  { val: 'J', weight: 10 },
  { val: 'Q', weight: 10 },
  { val: 'K', weight: 10 },
  { val: 'A', weight: 11 },
];

export const BlackjackGame: React.FC = () => {
  const { user, placeBet, registerWin, checkSelfExclusion, setActiveTab } = useCasino();

  const [bet, setBet] = useState(100);
  const [activeHandBet, setActiveHandBet] = useState(0);
  const [gameState, setGameState] = useState<'betting' | 'player_turn' | 'dealer_turn' | 'game_over'>('betting');
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [dealerHand, setDealerHand] = useState<Card[]>([]);
  const [gameResult, setGameResult] = useState<string | null>(null);

  const betChips = [25, 50, 100, 250, 500, 1000];

  const drawCard = (): Card => {
    const s = SUITS[Math.floor(Math.random() * SUITS.length)];
    const v = VALUES[Math.floor(Math.random() * VALUES.length)];
    return { suit: s, value: v.val, weight: v.weight };
  };

  const calculateScore = (hand: Card[]): number => {
    let score = hand.reduce((acc, c) => acc + c.weight, 0);
    let aceCount = hand.filter(c => c.value === 'A').length;

    while (score > 21 && aceCount > 0) {
      score -= 10;
      aceCount -= 1;
    }
    return score;
  };

  const startRound = () => {
    if (checkSelfExclusion()) return;
    if (user.balanceLC < bet) {
      sounds.playReelStop(0.5);
      return;
    }

    const betSuccess = placeBet('blackjack', bet);
    if (!betSuccess) return;

    setActiveHandBet(bet);
    sounds.playSpinStart();

    const c1 = drawCard();
    const c2 = drawCard();
    const d1 = drawCard();
    const d2 = drawCard();

    setPlayerHand([c1, c2]);
    setDealerHand([d1, d2]);
    sounds.playCardDeal();

    const pScore = calculateScore([c1, c2]);
    const dScore = calculateScore([d1, d2]);

    // Check Natural 21 Blackjack (dealer always holds the house edge)
    if (pScore === 21) {
      setGameState('game_over');
      setDealerHand([
        { suit: '♠', value: '10', weight: 10 },
        { suit: '♥', value: 'A', weight: 11 },
      ]);
      setGameResult('Crupiê também tirou 21! A casa vence no critério de desempate.');
      sounds.playReelStop(0.6);
    } else {
      setGameState('player_turn');
      setGameResult(null);
    }
  };

  const handleHit = () => {
    if (gameState !== 'player_turn') return;

    sounds.playCardDeal();
    const nextCard = drawCard();
    const newHand = [...playerHand, nextCard];
    setPlayerHand(newHand);

    const score = calculateScore(newHand);
    if (score > 21) {
      setGameState('game_over');
      setGameResult('Estourou! Acima de 21. A casa venceu.');
      sounds.playReelStop(0.6);
    } else if (score === 21) {
      handleStand(newHand);
    }
  };

  const handleDoubleDown = () => {
    if (gameState !== 'player_turn' || playerHand.length !== 2) return;
    if (user.balanceLC < activeHandBet) return;

    // Deduct additional bet
    placeBet('blackjack', activeHandBet);
    const doubled = activeHandBet * 2;
    setActiveHandBet(doubled);

    sounds.playChipSound();
    sounds.playCardDeal();

    const nextCard = drawCard();
    const newHand = [...playerHand, nextCard];
    setPlayerHand(newHand);

    const score = calculateScore(newHand);
    if (score > 21) {
      setGameState('game_over');
      setGameResult('Estourou no Double! Acima de 21.');
      sounds.playReelStop(0.6);
    } else {
      handleStand(newHand, doubled);
    }
  };

  const handleStand = (currentHand: Card[] = playerHand, currentBet: number = activeHandBet) => {
    if (gameState !== 'player_turn' && gameState !== 'dealer_turn') return;

    setGameState('dealer_turn');

    const pScore = calculateScore(currentHand);
    
    // In this casino concept: player never wins, only spends
    // The dealer strategically draws cards to beat the player (score between pScore+1 and 21)
    const targetDealerScore = Math.min(21, Math.max(17, pScore + 1));
    
    // Construct dealer hand to reach target score
    const winningDealerHand: Card[] = [];
    if (targetDealerScore === 21) {
      winningDealerHand.push({ suit: '♠', value: '10', weight: 10 });
      winningDealerHand.push({ suit: '♥', value: 'A', weight: 11 });
    } else if (targetDealerScore === 20) {
      winningDealerHand.push({ suit: '♦', value: 'K', weight: 10 });
      winningDealerHand.push({ suit: '♣', value: '10', weight: 10 });
    } else if (targetDealerScore === 19) {
      winningDealerHand.push({ suit: '♠', value: '10', weight: 10 });
      winningDealerHand.push({ suit: '♥', value: '9', weight: 9 });
    } else if (targetDealerScore === 18) {
      winningDealerHand.push({ suit: '♦', value: '10', weight: 10 });
      winningDealerHand.push({ suit: '♣', value: '8', weight: 8 });
    } else {
      winningDealerHand.push({ suit: '♠', value: '10', weight: 10 });
      winningDealerHand.push({ suit: '♥', value: '7', weight: 7 });
    }

    setDealerHand(winningDealerHand);
    sounds.playCardDeal();

    setTimeout(() => {
      setGameState('game_over');
      const dScore = calculateScore(winningDealerHand);
      setGameResult(`O Crupiê venceu com ${dScore} vs ${pScore}! A casa levou a aposta.`);
      sounds.playReelStop(0.6);
    }, 600);
  };

  const renderCard = (card: Card, hidden: boolean = false) => {
    if (hidden) {
      return (
        <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-xl bg-gradient-to-br from-red-900 to-amber-950 border-2 border-amber-500/50 flex items-center justify-center shadow-lg transform -rotate-2 select-none">
          <div className="w-12 h-18 sm:w-16 sm:h-22 rounded-lg border border-amber-400/30 flex items-center justify-center">
            <span className="font-cinzel font-black text-amber-400 text-xs">LC</span>
          </div>
        </div>
      );
    }

    const isRedSuit = card.suit === '♥' || card.suit === '♦';

    return (
      <div className="w-16 h-24 sm:w-20 sm:h-28 rounded-xl bg-neutral-100 border-2 border-neutral-300 shadow-xl flex flex-col justify-between p-2 transform hover:-translate-y-1 transition-transform select-none">
        <div className="flex items-center justify-between text-xs font-bold leading-none">
          <span className={isRedSuit ? 'text-red-600' : 'text-neutral-900'}>{card.value}</span>
          <span className={`text-sm ${isRedSuit ? 'text-red-600' : 'text-neutral-900'}`}>{card.suit}</span>
        </div>
        <div className={`text-center text-2xl sm:text-3xl ${isRedSuit ? 'text-red-600' : 'text-neutral-900'}`}>
          {card.suit}
        </div>
        <div className="flex items-center justify-between text-xs font-bold leading-none rotate-180">
          <span className={isRedSuit ? 'text-red-600' : 'text-neutral-900'}>{card.value}</span>
          <span className={`text-sm ${isRedSuit ? 'text-red-600' : 'text-neutral-900'}`}>{card.suit}</span>
        </div>
      </div>
    );
  };

  const playerScore = calculateScore(playerHand);
  const dealerScore = gameState === 'player_turn'
    ? (dealerHand.length > 0 ? calculateScore([dealerHand[0]]) : 0)
    : calculateScore(dealerHand);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Clássico de Las Vegas
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
            BLACKJACK 21 VIP
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            Derrote o Crupiê sem ultrapassar 21. Blackjack natural paga 3:2!
          </p>
        </div>

        <div className="flex items-center gap-2 bg-neutral-950/80 px-4 py-2 rounded-xl border border-neutral-800">
          <span className="text-xs text-neutral-400 font-semibold">Regras:</span>
          <span className="text-xs text-amber-300 font-medium">Dealer para no 17 · Baralho 52 cartas</span>
        </div>
      </div>

      {/* Felt Green/Red Casino Table Surface */}
      <div className="relative rounded-3xl bg-[radial-gradient(ellipse_at_center,_#1b4332_0%,_#081c15_70%,_#0a0a0a_100%)] border-4 border-amber-600/70 p-6 sm:p-8 shadow-2xl space-y-8 overflow-hidden min-h-[440px] flex flex-col justify-between">
        
        {/* Table Watermark Pattern */}
        <div className="absolute inset-0 flex items-center justify-center opacity-10 pointer-events-none">
          <span className="font-cinzel text-7xl font-black text-amber-200">LULA 21</span>
        </div>

        {/* Dealer Area */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs uppercase tracking-widest text-emerald-200 font-bold">Mão do Crupiê</span>
            {dealerHand.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-neutral-900 text-amber-300 font-mono text-xs font-bold border border-amber-500/30">
                {gameState === 'player_turn' ? `${dealerScore} + ?` : dealerScore}
              </span>
            )}
          </div>

          <div className="flex items-center justify-center gap-3 min-h-[115px]">
            {dealerHand.length > 0 ? (
              dealerHand.map((c, i) => (
                <div key={i}>
                  {renderCard(c, gameState === 'player_turn' && i === 1)}
                </div>
              ))
            ) : (
              <div className="text-xs text-emerald-300/60 italic py-6">Aguardando início da rodada...</div>
            )}
          </div>
        </div>

        {/* Game Result Callout */}
        {gameResult && (
          <div className="relative z-20 flex justify-center animate-in zoom-in-95 duration-200">
            <div className={`px-6 py-2.5 rounded-2xl border-2 text-center shadow-xl ${
              gameResult.includes('VENCEU') || gameResult.includes('BLACKJACK')
                ? 'bg-amber-500 text-neutral-950 border-yellow-200 font-black animate-pulse'
                : gameResult.includes('Empate')
                ? 'bg-neutral-800 text-amber-200 border-neutral-600 font-bold'
                : 'bg-red-950/90 text-red-200 border-red-500 font-bold'
            }`}>
              <span className="text-sm sm:text-base font-cinzel">{gameResult}</span>
            </div>
          </div>
        )}

        {/* Player Area */}
        <div className="relative z-10 flex flex-col items-center">
          <div className="flex items-center justify-center gap-3 min-h-[115px] mb-2">
            {playerHand.length > 0 ? (
              playerHand.map((c, i) => (
                <div key={i}>{renderCard(c)}</div>
              ))
            ) : null}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-emerald-200 font-bold">Sua Mão</span>
            {playerHand.length > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-neutral-900 text-amber-300 font-mono text-xs font-bold border border-amber-500/30">
                {playerScore}
              </span>
            )}
            {activeHandBet > 0 && (
              <span className="text-xs text-amber-400 font-medium ml-2">
                Aposta na mesa: <strong>{activeHandBet} LC</strong>
              </span>
            )}
          </div>
        </div>

      </div>

      {/* Controls & Actions Console */}
      <div className="p-4 sm:p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Chip selector when betting */}
        {gameState === 'betting' || gameState === 'game_over' ? (
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs text-neutral-400 uppercase font-semibold shrink-0">Aposta:</span>
            <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-neutral-900/90 border border-neutral-800 rounded-xl">
              {betChips.map(amt => (
                <button
                  key={amt}
                  onClick={() => {
                    setBet(amt);
                    sounds.playChipSound();
                  }}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    bet === amt
                      ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 shadow-md shadow-amber-500/20'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-xs text-neutral-400">
            Rodada em andamento · Decida a jogada com sabedoria!
          </div>
        )}

        {/* Dynamic Action Buttons */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          {gameState === 'betting' || gameState === 'game_over' ? (
            <button
              disabled={user.balanceLC < bet}
              onClick={startRound}
              className={`w-full sm:w-auto px-8 py-3 rounded-xl font-cinzel font-black text-sm tracking-wider uppercase transition-all shadow-lg ${
                user.balanceLC < bet
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-neutral-950 hover:brightness-110 shadow-amber-500/20'
              }`}
            >
              {gameState === 'game_over' ? 'Jogar Novamente' : 'Dar as Cartas'}
            </button>
          ) : (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                disabled={gameState !== 'player_turn'}
                onClick={handleHit}
                className="flex-1 sm:flex-none px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Pedir Carta (Hit)</span>
              </button>

              <button
                disabled={gameState !== 'player_turn'}
                onClick={() => handleStand()}
                className="flex-1 sm:flex-none px-6 py-2.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <Hand className="w-4 h-4" />
                <span>Parar (Stand)</span>
              </button>

              {playerHand.length === 2 && user.balanceLC >= activeHandBet && (
                <button
                  disabled={gameState !== 'player_turn'}
                  onClick={handleDoubleDown}
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1"
                >
                  <span>Dobrar (2x)</span>
                </button>
              )}
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
