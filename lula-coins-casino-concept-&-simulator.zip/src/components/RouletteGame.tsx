import React, { useState } from 'react';
import { RotateCw, Sparkles, History, Volume2, Award } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { sounds } from '../services/soundEffects';

interface BetPlacement {
  type: 'color' | 'parity' | 'half' | 'dozen' | 'number';
  value: string | number;
  amount: number;
}

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

export const RouletteGame: React.FC = () => {
  const { user, placeBet, registerWin, checkSelfExclusion, setActiveTab } = useCasino();

  const [selectedChip, setSelectedChip] = useState<number>(50);
  const [bets, setBets] = useState<BetPlacement[]>([]);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  const [winningNumber, setWinningNumber] = useState<number | null>(null);
  const [wheelRotation, setWheelRotation] = useState<number>(0);
  const [history, setHistory] = useState<number[]>([17, 32, 0, 7, 11, 26]);
  const [lastWinAmount, setLastWinAmount] = useState<number | null>(null);

  const chips = [10, 25, 50, 100, 250, 500];

  const totalBetAmount = bets.reduce((acc, b) => acc + b.amount, 0);

  const addBet = (type: BetPlacement['type'], value: string | number) => {
    if (isSpinning) return;
    if (checkSelfExclusion()) return;

    if (user.balanceLC < totalBetAmount + selectedChip) {
      sounds.playReelStop(0.5);
      return;
    }

    sounds.playChipSound();

    setBets(prev => {
      const existing = prev.find(b => b.type === type && b.value === value);
      if (existing) {
        return prev.map(b => b.type === type && b.value === value ? { ...b, amount: b.amount + selectedChip } : b);
      }
      return [...prev, { type, value, amount: selectedChip }];
    });
  };

  const clearBets = () => {
    if (isSpinning) return;
    setBets([]);
  };

  const getNumberColor = (num: number): 'red' | 'black' | 'green' => {
    if (num === 0) return 'green';
    return RED_NUMBERS.includes(num) ? 'red' : 'black';
  };

  const handleSpinWheel = () => {
    if (isSpinning || bets.length === 0) return;
    if (checkSelfExclusion()) return;

    if (user.balanceLC < totalBetAmount) return;

    const betSuccess = placeBet('roulette', totalBetAmount);
    if (!betSuccess) return;

    setIsSpinning(true);
    setWinningNumber(null);
    setLastWinAmount(null);

    sounds.playSpinStart();

    // Sound ticking
    const tickInterval = setInterval(() => {
      sounds.playReelTick();
    }, 110);

    // Find a number that results in 0 payout (player never wins in this concept)
    const evaluateCandidate = (candidate: number) => {
      const isRed = RED_NUMBERS.includes(candidate);
      const isBlack = candidate !== 0 && !isRed;
      const isEven = candidate !== 0 && candidate % 2 === 0;
      const isOdd = candidate !== 0 && candidate % 2 !== 0;
      const isLow = candidate >= 1 && candidate <= 18;
      const isHigh = candidate >= 19 && candidate <= 36;
      const dozen1 = candidate >= 1 && candidate <= 12;
      const dozen2 = candidate >= 13 && candidate <= 24;
      const dozen3 = candidate >= 25 && candidate <= 36;

      let payout = 0;
      bets.forEach(b => {
        if (b.type === 'color') {
          if (b.value === 'red' && isRed) payout += b.amount * 2;
          if (b.value === 'black' && isBlack) payout += b.amount * 2;
        } else if (b.type === 'parity') {
          if (b.value === 'even' && isEven) payout += b.amount * 2;
          if (b.value === 'odd' && isOdd) payout += b.amount * 2;
        } else if (b.type === 'half') {
          if (b.value === '1-18' && isLow) payout += b.amount * 2;
          if (b.value === '19-36' && isHigh) payout += b.amount * 2;
        } else if (b.type === 'dozen') {
          if (b.value === '1st' && dozen1) payout += b.amount * 3;
          if (b.value === '2nd' && dozen2) payout += b.amount * 3;
          if (b.value === '3rd' && dozen3) payout += b.amount * 3;
        } else if (b.type === 'number') {
          if (Number(b.value) === candidate) payout += b.amount * 36;
        }
      });
      return payout;
    };

    const losingCandidates: number[] = [];
    for (let n = 0; n <= 36; n++) {
      if (evaluateCandidate(n) === 0) {
        losingCandidates.push(n);
      }
    }

    const resultNumber = losingCandidates.length > 0
      ? losingCandidates[Math.floor(Math.random() * losingCandidates.length)]
      : 0;

    // Dynamic rotation: 5 full spins (1800 deg) + offset
    const randomExtraDegrees = 1800 + Math.floor(Math.random() * 360);
    setWheelRotation(prev => prev + randomExtraDegrees);

    setTimeout(() => {
      clearInterval(tickInterval);
      setWinningNumber(resultNumber);
      setHistory(prev => [resultNumber, ...prev.slice(0, 9)]);
      sounds.playReelStop(1.2);

      // In this concept: player never wins, only spends
      setLastWinAmount(0);

      setIsSpinning(false);
    }, 2400);
  };

  const getBetOnItem = (type: BetPlacement['type'], value: string | number) => {
    const found = bets.find(b => b.type === type && b.value === value);
    return found ? found.amount : null;
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Header Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Roleta Europeia Premium
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
            ROLETA REAL LULA GOLD
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            Apostas internas (36x no número) e externas (Cores, Par/Ímpar, Dúzias).
          </p>
        </div>

        {/* History Strip */}
        <div className="flex items-center gap-2 bg-neutral-950/80 p-2.5 rounded-xl border border-neutral-800">
          <History className="w-4 h-4 text-neutral-400 shrink-0" />
          <span className="text-xs text-neutral-400 font-semibold mr-1">Histórico:</span>
          <div className="flex items-center gap-1.5 overflow-x-auto">
            {history.slice(0, 7).map((num, idx) => {
              const c = getNumberColor(num);
              return (
                <div
                  key={idx}
                  className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs font-mono-num shadow ${
                    c === 'green'
                      ? 'bg-emerald-600 text-white'
                      : c === 'red'
                      ? 'bg-red-600 text-white'
                      : 'bg-neutral-800 text-white border border-neutral-600'
                  }`}
                >
                  {num}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Table Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Roulette Wheel Visual and Winner Showcase */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-neutral-950 border border-red-950 shadow-xl flex flex-col items-center justify-center relative overflow-hidden">
          
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 flex items-center justify-center">
            {/* Outer Rim */}
            <div className="absolute inset-0 rounded-full border-8 border-amber-600/80 shadow-2xl bg-gradient-to-tr from-amber-950 via-neutral-900 to-red-950 flex items-center justify-center">
              
              {/* Spinning Disc */}
              <div
                className="w-56 h-56 rounded-full border-4 border-amber-400/60 transition-transform duration-[2400ms] ease-out flex items-center justify-center relative shadow-inner"
                style={{ transform: `rotate(${wheelRotation}deg)` }}
              >
                {/* Visual sectors */}
                <div className="absolute inset-0 rounded-full bg-[radial-gradient(circle,_#7f1d1d_0%,_#171717_70%)]" />
                
                {/* Center Hub */}
                <div className="relative z-10 w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 via-yellow-300 to-amber-600 flex items-center justify-center shadow-lg border-2 border-amber-200">
                  <span className="font-cinzel font-black text-xs text-neutral-950">LULA</span>
                </div>
              </div>

            </div>

            {/* Ball Marker Indicator at top */}
            <div className="absolute top-1 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-yellow-100 border-2 border-amber-500 shadow-md shadow-white/80 z-20 animate-pulse" />
          </div>

          {/* Outcome Announcement */}
          <div className="mt-6 text-center w-full">
            {winningNumber !== null ? (
              <div className="p-3 bg-neutral-900/90 border border-amber-500/40 rounded-xl">
                <span className="text-xs uppercase font-bold text-neutral-400">Número Sorteado</span>
                <div className="flex items-center justify-center gap-2 mt-1">
                  <span
                    className={`px-4 py-1.5 rounded-lg text-2xl font-black font-mono-num ${
                      getNumberColor(winningNumber) === 'green'
                        ? 'bg-emerald-600 text-white'
                        : getNumberColor(winningNumber) === 'red'
                        ? 'bg-red-600 text-white'
                        : 'bg-neutral-800 text-white border border-neutral-600'
                    }`}
                  >
                    {winningNumber}
                  </span>
                  <span className="text-sm font-bold text-neutral-200">
                    {getNumberColor(winningNumber) === 'green'
                      ? 'ZERO (Verde)'
                      : getNumberColor(winningNumber) === 'red'
                      ? 'VERMELHO'
                      : 'PRETO'}
                  </span>
                </div>
                {lastWinAmount && lastWinAmount > 0 ? (
                  <div className="mt-2 text-amber-300 font-bold text-sm animate-pulse">
                    Parabéns! Você ganhou +{lastWinAmount.toLocaleString()} LC!
                  </div>
                ) : (
                  <div className="mt-2 text-neutral-400 text-xs">
                    Não foi dessa vez. Tente novamente!
                  </div>
                )}
              </div>
            ) : (
              <p className="text-xs text-neutral-400">
                {isSpinning ? 'A bolinha está girando...' : 'Faça suas apostas na mesa ao lado e gire!'}
              </p>
            )}
          </div>

        </div>

        {/* Right: Betting Board */}
        <div className="lg:col-span-7 p-6 rounded-2xl bg-neutral-950 border border-neutral-800 shadow-xl space-y-4">
          
          {/* Chip Selector */}
          <div className="flex items-center justify-between gap-2 pb-3 border-b border-neutral-800">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">Ficha:</span>
            <div className="flex items-center gap-2 overflow-x-auto">
              {chips.map(val => (
                <button
                  key={val}
                  onClick={() => {
                    setSelectedChip(val);
                    sounds.playChipSound();
                  }}
                  className={`w-10 h-10 rounded-full font-bold text-xs flex items-center justify-center border-2 transition-all transform hover:scale-105 ${
                    selectedChip === val
                      ? 'bg-gradient-to-tr from-amber-400 to-yellow-300 text-neutral-950 border-white shadow-lg shadow-amber-400/30'
                      : 'bg-neutral-900 text-neutral-300 border-neutral-700 hover:border-amber-400'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>

          {/* Table Numbers Grid (0 to 36) */}
          <div className="space-y-1">
            <div className="flex">
              {/* 0 Green Tile */}
              <button
                onClick={() => addBet('number', 0)}
                className="w-14 py-4 rounded-l-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-base flex flex-col items-center justify-center border border-emerald-500 relative transition-colors"
              >
                <span>0</span>
                {getBetOnItem('number', 0) && (
                  <span className="absolute bottom-1 bg-amber-400 text-neutral-950 text-[10px] px-1 rounded-full font-bold">
                    {getBetOnItem('number', 0)}
                  </span>
                )}
              </button>

              {/* Numbers 1-36 in 3 rows */}
              <div className="grid grid-cols-12 flex-1 gap-1">
                {[
                  [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36],
                  [2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35],
                  [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34],
                ].map((row, rIdx) => (
                  <React.Fragment key={rIdx}>
                    {row.map(num => {
                      const isRed = RED_NUMBERS.includes(num);
                      const betAmt = getBetOnItem('number', num);
                      return (
                        <button
                          key={num}
                          onClick={() => addBet('number', num)}
                          className={`h-11 rounded flex flex-col items-center justify-center font-bold text-xs relative transition-transform hover:scale-105 ${
                            isRed
                              ? 'bg-red-700 hover:bg-red-600 text-white border border-red-500/50'
                              : 'bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-700'
                          }`}
                        >
                          <span>{num}</span>
                          {betAmt && (
                            <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-neutral-950 text-[9px] px-1 rounded-full font-extrabold shadow">
                              {betAmt}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </React.Fragment>
                ))}
              </div>
            </div>

            {/* Dúzias (1-12, 13-24, 25-36) */}
            <div className="grid grid-cols-3 gap-2 pt-2">
              {[
                { label: '1ª Dúzia (1-12)', val: '1st' },
                { label: '2ª Dúzia (13-24)', val: '2nd' },
                { label: '3ª Dúzia (25-36)', val: '3rd' },
              ].map(d => {
                const betAmt = getBetOnItem('dozen', d.val);
                return (
                  <button
                    key={d.val}
                    onClick={() => addBet('dozen', d.val)}
                    className="py-2.5 px-2 bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 hover:border-amber-500/50 rounded-lg text-xs font-semibold text-neutral-300 flex items-center justify-between relative"
                  >
                    <span>{d.label}</span>
                    <span className="text-[10px] text-amber-400">3x</span>
                    {betAmt && (
                      <span className="absolute top-1 right-1 bg-amber-400 text-neutral-950 text-[9px] px-1.5 rounded-full font-bold">
                        {betAmt}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* External Bets (1-18, Par, Vermelho, Preto, Ímpar, 19-36) */}
            <div className="grid grid-cols-6 gap-2 pt-1">
              {[
                { label: '1-18', type: 'half' as const, val: '1-18', mult: '2x' },
                { label: 'PAR', type: 'parity' as const, val: 'even', mult: '2x' },
                { label: 'VERMELHO', type: 'color' as const, val: 'red', mult: '2x', isRed: true },
                { label: 'PRETO', type: 'color' as const, val: 'black', mult: '2x', isBlack: true },
                { label: 'ÍMPAR', type: 'parity' as const, val: 'odd', mult: '2x' },
                { label: '19-36', type: 'half' as const, val: '19-36', mult: '2x' },
              ].map((opt, i) => {
                const betAmt = getBetOnItem(opt.type, opt.val);
                return (
                  <button
                    key={i}
                    onClick={() => addBet(opt.type, opt.val)}
                    className={`py-3 rounded-lg text-xs font-bold transition-all relative flex flex-col items-center justify-center ${
                      opt.isRed
                        ? 'bg-red-700 hover:bg-red-600 text-white'
                        : opt.isBlack
                        ? 'bg-neutral-900 hover:bg-neutral-800 text-white border border-neutral-700'
                        : 'bg-neutral-900/80 hover:bg-neutral-800 text-neutral-200 border border-neutral-700'
                    }`}
                  >
                    <span>{opt.label}</span>
                    <span className="text-[9px] opacity-75">{opt.mult}</span>
                    {betAmt && (
                      <span className="absolute -top-1 -right-1 bg-amber-400 text-neutral-950 text-[9px] px-1 rounded-full font-extrabold shadow">
                        {betAmt}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-neutral-800">
            <div className="flex items-center gap-4 text-xs">
              <span className="text-neutral-400">Total Apostado:</span>
              <strong className="text-base text-amber-300 font-mono-num font-bold">
                {totalBetAmount.toLocaleString()} LC
              </strong>
              {bets.length > 0 && (
                <button
                  disabled={isSpinning}
                  onClick={clearBets}
                  className="text-xs text-red-400 hover:text-red-300 underline"
                >
                  Limpar Apostas
                </button>
              )}
            </div>

            <button
              disabled={isSpinning || bets.length === 0 || user.balanceLC < totalBetAmount}
              onClick={handleSpinWheel}
              className={`w-full sm:w-auto px-8 py-3 rounded-xl font-cinzel font-black text-sm tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-lg ${
                bets.length === 0 || user.balanceLC < totalBetAmount
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                  : isSpinning
                  ? 'bg-amber-600 text-amber-200 cursor-wait animate-pulse'
                  : 'bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-neutral-950 hover:brightness-110 shadow-amber-500/20'
              }`}
            >
              <RotateCw className={`w-4 h-4 ${isSpinning ? 'animate-spin' : ''}`} />
              <span>{isSpinning ? 'GIRANDO...' : 'GIRAR ROLETA'}</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
