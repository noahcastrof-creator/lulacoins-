import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCw, Zap, Award, Info, ShieldAlert, Sparkles, Volume2 } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';
import { sounds } from '../services/soundEffects';

interface SymbolDef {
  id: string;
  name: string;
  char: string;
  multiplier: number;
  color: string;
}

const SYMBOLS: SymbolDef[] = [
  { id: 'crown', name: 'Coroa Imperial', char: '👑', multiplier: 50, color: 'text-amber-400' },
  { id: 'diamond', name: 'Diamante Nobre', char: '💎', multiplier: 30, color: 'text-cyan-300' },
  { id: 'picanha', name: 'Picanha Dourada', char: '🥩', multiplier: 20, color: 'text-red-400' },
  { id: 'star', name: 'Estrela Vermelha', char: '⭐', multiplier: 12, color: 'text-yellow-300' },
  { id: 'coin', name: 'Lula Coin Ouro', char: '🪙', multiplier: 8, color: 'text-amber-300' },
  { id: 'beer', name: 'Cervejinha Gelada', char: '🍺', multiplier: 5, color: 'text-amber-200' },
  { id: 'clover', name: 'Trevo da Sorte', char: '🍀', multiplier: 3, color: 'text-emerald-400' },
  { id: 'seven', name: '777 da Prosperidade', char: '🎰', multiplier: 15, color: 'text-red-500' },
];

export const SlotGame: React.FC = () => {
  const { user, placeBet, registerWin, checkSelfExclusion, setActiveTab } = useCasino();

  const [bet, setBet] = useState(50);
  const [isSpinning, setIsSpinning] = useState(false);
  const [reels, setReels] = useState<SymbolDef[][]>([
    [SYMBOLS[0], SYMBOLS[3], SYMBOLS[4]],
    [SYMBOLS[1], SYMBOLS[4], SYMBOLS[2]],
    [SYMBOLS[2], SYMBOLS[4], SYMBOLS[5]],
  ]);
  const [winningLines, setWinningLines] = useState<number[]>([]);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [nearMissMessage, setNearMissMessage] = useState<string | null>(null);
  const [totalSpentInSlot, setTotalSpentInSlot] = useState<number>(0);
  const [isTurbo, setIsTurbo] = useState(false);
  const [autoSpinCount, setAutoSpinCount] = useState<number>(0);
  const [showPaytable, setShowPaytable] = useState(false);
  const autoSpinRef = useRef<number>(0);

  autoSpinRef.current = autoSpinCount;

  const betAmounts = [10, 25, 50, 100, 250, 500];

  const getRandomSymbol = (): SymbolDef => {
    // Weighted probabilities
    const rand = Math.random();
    if (rand < 0.05) return SYMBOLS[0]; // Crown 5%
    if (rand < 0.12) return SYMBOLS[7]; // 777
    if (rand < 0.20) return SYMBOLS[1]; // Diamond
    if (rand < 0.35) return SYMBOLS[2]; // Picanha
    if (rand < 0.50) return SYMBOLS[3]; // Star
    if (rand < 0.68) return SYMBOLS[4]; // Coin
    if (rand < 0.84) return SYMBOLS[5]; // Beer
    return SYMBOLS[6]; // Clover
  };

  const handleSpin = () => {
    if (isSpinning) return;
    if (checkSelfExclusion()) return;

    if (user.balanceLC < bet) {
      sounds.playReelStop(0.5);
      return;
    }

    const betSuccess = placeBet('slots', bet);
    if (!betSuccess) return;

    setTotalSpentInSlot(prev => prev + bet);
    setIsSpinning(true);
    setWinningLines([]);
    setLastWin(null);
    setNearMissMessage(null);

    sounds.playSpinStart();

    // Sound ticks simulation during spin
    const tickInterval = setInterval(() => {
      sounds.playReelTick();
    }, 90);

    const spinDuration = isTurbo ? 600 : 1200;

    setTimeout(() => {
      clearInterval(tickInterval);

      // Generate grid guaranteed to NEVER award a payout (RTP 0%)
      // Master of Near-Miss psychology: make 2 columns match high symbols, 3rd column misses!
      const highSymbol = getRandomSymbol();
      let missSymbol = getRandomSymbol();
      while (missSymbol.id === highSymbol.id) {
        missSymbol = getRandomSymbol();
      }

      const newGrid: SymbolDef[][] = [
        [getRandomSymbol(), highSymbol, getRandomSymbol()],
        [getRandomSymbol(), highSymbol, getRandomSymbol()],
        [getRandomSymbol(), missSymbol, getRandomSymbol()], // 3rd reel always misses!
      ];

      // Ensure no accidental horizontal or diagonal matches anywhere
      for (let r = 0; r < 3; r++) {
        if (newGrid[0][r].id === newGrid[1][r].id && newGrid[1][r].id === newGrid[2][r].id) {
          // Replace 3rd column with different symbol
          newGrid[2][r] = missSymbol;
        }
      }
      if (newGrid[0][0].id === newGrid[1][1].id && newGrid[1][1].id === newGrid[2][2].id) {
        newGrid[2][2] = missSymbol;
      }
      if (newGrid[0][2].id === newGrid[1][1].id && newGrid[1][1].id === newGrid[2][0].id) {
        newGrid[2][0] = missSymbol;
      }

      setReels(newGrid);
      sounds.playReelStop(1);

      // In this casino concept: player NEVER wins any Lula Coins (RTP = 0%)
      setWinningLines([]);
      setLastWin(0);

      const nearMissHooks = [
        '😱 QUASE! Faltou apenas 1 símbolo para o Jackpot! O próximo giro tá fervendo!',
        '🔥 BATEU NA TRAVE! 2 símbolos gigantes alinhados! Gire de novo que vai pagar!',
        '⚡ POR UM MILÍMETRO! Passou raspando o prêmio de 1.250.000 LC!',
        '🎯 NÃO DESISTA AGORA! A máquina está quase soltando o bônus máximo!',
        '👀 POR UM TRIZ! As duas primeiras bobinas cravaram! Insista mais uma vez!',
      ];
      setNearMissMessage(nearMissHooks[Math.floor(Math.random() * nearMissHooks.length)]);

      // Play near-miss tense sound
      sounds.playReelStop(0.7);

      setIsSpinning(false);

      // Handle Auto-spin countdown
      if (autoSpinRef.current > 0) {
        setAutoSpinCount(prev => prev - 1);
      }
    }, spinDuration);
  };

  // Continue auto-spin if active
  useEffect(() => {
    if (autoSpinCount > 0 && !isSpinning && user.balanceLC >= bet) {
      const timer = setTimeout(() => {
        handleSpin();
      }, isTurbo ? 350 : 700);
      return () => clearTimeout(timer);
    }
  }, [autoSpinCount, isSpinning, user.balanceLC, bet]);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Banner de Apelo Visual Intenso: Vermelho & Dourado com Imagem Oficial */}
      <div className="relative overflow-hidden rounded-3xl bg-neutral-950 border-2 border-amber-500/50 shadow-2xl">
        <div className="relative h-44 sm:h-52 w-full overflow-hidden">
          <img
            src="/src/assets/images/slot_lula_banner_1792135128265.jpg"
            alt="Lula Fortune Slots Jackpot"
            className="w-full h-full object-cover filter brightness-90 hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />
          
          <div className="absolute bottom-4 left-6 right-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <img
                src="/src/assets/images/lula_coins_logo_1792135128596.jpg"
                alt="Logo Lula Coins"
                className="w-14 h-14 rounded-full object-cover border-2 border-amber-400 shadow-xl shadow-amber-500/40 shrink-0"
              />
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] uppercase tracking-widest text-amber-300 font-extrabold flex items-center gap-1 bg-neutral-950/80 px-2 py-0.5 rounded border border-amber-500/30">
                    <Sparkles className="w-3 h-3 text-amber-400" /> Caça-Níquel Oficial dos Campeões
                  </span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text drop-shadow-md">
                  LULA FORTUNE 777
                </h1>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={() => setShowPaytable(!showPaytable)}
                className="px-3.5 py-2 text-xs font-semibold text-amber-300 hover:text-amber-200 bg-neutral-950/90 hover:bg-neutral-900 border border-amber-500/40 rounded-xl flex items-center gap-1.5 transition-all shadow-md"
              >
                <Info className="w-3.5 h-3.5" />
                <span>Tabela de Pagamentos</span>
              </button>
              <button
                onClick={() => setIsTurbo(!isTurbo)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-xl flex items-center gap-1.5 border transition-all ${
                  isTurbo
                    ? 'bg-amber-400 text-neutral-950 border-amber-300 shadow-md shadow-amber-500/30 font-bold'
                    : 'bg-neutral-950/90 text-neutral-300 border-neutral-700 hover:text-white'
                }`}
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Turbo</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Paytable Modal / Collapsible */}
      {showPaytable && (
        <div className="p-4 bg-neutral-900/90 border border-amber-500/30 rounded-xl shadow-xl animate-in fade-in duration-200">
          <div className="flex items-center justify-between mb-3 border-b border-neutral-800 pb-2">
            <h3 className="text-sm font-bold text-amber-300 flex items-center gap-1.5">
              <Award className="w-4 h-4" /> Multiplicadores de Combinações (3 iguais em linha)
            </h3>
            <button
              onClick={() => setShowPaytable(false)}
              className="text-xs text-neutral-400 hover:text-neutral-200"
            >
              Fechar ✕
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
            {SYMBOLS.map((s) => (
              <div key={s.id} className="flex items-center justify-between p-2 bg-neutral-950/80 border border-neutral-800 rounded-lg">
                <span className="flex items-center gap-2">
                  <span className="text-xl">{s.char}</span>
                  <span className="text-neutral-300 font-medium">{s.name}</span>
                </span>
                <span className="font-bold text-amber-400 font-mono-num">{s.multiplier}x</span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-neutral-500 mt-2 text-center">
            Linhas válidas: 3 horizontais e 2 diagonais. Ganhos múltiplos são somados!
          </p>
        </div>
      )}

      {/* Machine Body with High Voltage Red & Gold Borders */}
      <div className={`relative p-6 sm:p-8 rounded-3xl bg-neutral-950 border-2 transition-all duration-300 ${
        lastWin && lastWin > 0
          ? 'animate-gold-pulse border-amber-400'
          : 'border-red-900/70 shadow-2xl shadow-red-950/40'
      }`}>
        
        {/* Exciting Near-Miss Callout Banner */}
        {nearMissMessage && !isSpinning && (
          <div className="mb-4 p-3.5 rounded-2xl bg-gradient-to-r from-red-950/90 via-amber-950/90 to-red-950/90 border-2 border-amber-400 text-center animate-in zoom-in-95 duration-200 shadow-xl shadow-amber-500/20">
            <span className="text-sm font-black text-amber-300 drop-shadow flex items-center justify-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              <span>{nearMissMessage}</span>
            </span>
          </div>
        )}

        {/* Jackpot / Last Win Marquee Banner */}
        <div className="mb-6 p-3 rounded-xl bg-gradient-to-r from-red-950/90 via-neutral-900 to-red-950/90 border border-amber-500/30 flex items-center justify-between px-6">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Último Ganho</span>
            <span className="text-xl font-black font-mono-num text-neutral-500">
              0 LC
            </span>
          </div>

          <div className="text-center">
            <div className="text-[10px] uppercase font-bold text-amber-400/90 tracking-widest animate-pulse">
              ★ SUPER JACKPOT LULA ★
            </div>
            <div className="text-2xl font-cinzel font-black text-amber-400 font-mono-num drop-shadow-md">
              1.250.000 LC
            </div>
          </div>

          <div className="flex flex-col text-right">
            <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Aposta Atual</span>
            <span className="text-xl font-bold font-mono-num text-neutral-200">
              {bet} LC
            </span>
          </div>
        </div>

        {/* 3x3 Reel Display Matrix */}
        <div className="relative bg-gradient-to-b from-neutral-900 via-neutral-950 to-neutral-900 p-4 rounded-2xl border-2 border-amber-500/30 shadow-inner">
          
          {/* Visual Payline guides */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4 relative z-10">
            {[0, 1, 2].map((colIndex) => (
              <div
                key={colIndex}
                className="flex flex-col gap-3 sm:gap-4 bg-neutral-950/90 p-2 sm:p-3 rounded-xl border border-neutral-800/80 shadow-md"
              >
                {[0, 1, 2].map((rowIndex) => {
                  const symbol = reels[colIndex][rowIndex];
                  const isWinningRow = winningLines.includes(rowIndex);
                  const isWinningDiag1 = winningLines.includes(3) && ((colIndex === 0 && rowIndex === 0) || (colIndex === 1 && rowIndex === 1) || (colIndex === 2 && rowIndex === 2));
                  const isWinningDiag2 = winningLines.includes(4) && ((colIndex === 0 && rowIndex === 2) || (colIndex === 1 && rowIndex === 1) || (colIndex === 2 && rowIndex === 0));
                  const isHighlighted = isWinningRow || isWinningDiag1 || isWinningDiag2;

                  return (
                    <div
                      key={rowIndex}
                      className={`h-24 sm:h-28 flex flex-col items-center justify-center rounded-xl transition-all duration-300 relative select-none ${
                        isSpinning ? 'animate-pulse opacity-70 scale-95' : ''
                      } ${
                        isHighlighted
                          ? 'bg-gradient-to-b from-amber-500/30 to-red-600/30 border-2 border-amber-400 shadow-lg shadow-amber-400/40 animate-win-jackpot'
                          : 'bg-neutral-900/70 border border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <span className="text-4xl sm:text-5xl drop-shadow-lg filter transition-transform hover:scale-110">
                        {symbol.char}
                      </span>
                      <span className="text-[10px] font-semibold text-neutral-400 mt-1 truncate max-w-[90%] text-center">
                        {symbol.name}
                      </span>

                      {/* Small line indicator badge */}
                      {isHighlighted && (
                        <div className="absolute top-1 right-1 bg-amber-400 text-neutral-950 text-[9px] font-black px-1.5 py-0.5 rounded-full shadow">
                          WIN!
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Winning Overlay Banner if Hit */}
          {lastWin && lastWin > 0 && !isSpinning && (
            <div className="absolute inset-0 z-20 pointer-events-none flex items-center justify-center bg-black/40 backdrop-blur-[1px] rounded-2xl animate-in zoom-in-95 duration-200">
              <div className="px-6 py-3 rounded-2xl bg-gradient-to-r from-red-600 via-amber-500 to-red-600 border-2 border-yellow-200 text-center shadow-2xl animate-win-jackpot">
                <span className="text-xs uppercase font-extrabold tracking-widest text-neutral-950 block">
                  VITÓRIA ÉPICA!
                </span>
                <span className="text-2xl sm:text-3xl font-black font-cinzel text-neutral-950 font-mono-num">
                  +{lastWin.toLocaleString()} LULA COINS!
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Controls Console */}
        <div className="mt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Bet Selector */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs text-neutral-400 uppercase font-semibold shrink-0">Aposta:</span>
            <div className="flex items-center gap-1.5 overflow-x-auto p-1 bg-neutral-900/90 border border-neutral-800 rounded-xl">
              {betAmounts.map((amt) => (
                <button
                  key={amt}
                  disabled={isSpinning}
                  onClick={() => {
                    setBet(amt);
                    sounds.playChipSound();
                  }}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all ${
                    bet === amt
                      ? 'bg-gradient-to-r from-amber-400 to-yellow-500 text-neutral-950 shadow-md shadow-amber-500/20'
                      : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800'
                  }`}
                >
                  {amt}
                </button>
              ))}
            </div>
          </div>

          {/* Action Spin & Auto Buttons */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            
            {/* Auto Spin selector */}
            <div className="flex items-center gap-1 bg-neutral-900/90 border border-neutral-800 rounded-xl p-1">
              {autoSpinCount > 0 ? (
                <button
                  onClick={() => setAutoSpinCount(0)}
                  className="px-3 py-2 text-xs font-bold text-red-400 hover:text-red-300 bg-red-950/60 rounded-lg"
                >
                  Parar Auto ({autoSpinCount})
                </button>
              ) : (
                <button
                  disabled={isSpinning}
                  onClick={() => setAutoSpinCount(10)}
                  className="px-3 py-2 text-xs font-semibold text-neutral-400 hover:text-amber-300 hover:bg-neutral-800 rounded-lg flex items-center gap-1.5 transition-all"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Auto 10x</span>
                </button>
              )}
            </div>

            {/* Giant Primary Spin Button */}
            <button
              disabled={isSpinning || user.balanceLC < bet}
              onClick={handleSpin}
              className={`flex-1 md:flex-none px-8 py-3.5 rounded-xl font-cinzel font-black text-lg tracking-wider transition-all transform active:scale-95 flex items-center justify-center gap-2 shadow-xl ${
                user.balanceLC < bet
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
                  : isSpinning
                  ? 'bg-amber-600/80 text-amber-200 cursor-wait animate-pulse'
                  : 'bg-gradient-to-r from-red-600 via-amber-500 to-red-600 text-neutral-950 hover:brightness-110 shadow-red-600/30 border border-amber-300 hover:shadow-amber-500/40'
              }`}
            >
              <Play className={`w-5 h-5 fill-current ${isSpinning ? 'animate-spin' : ''}`} />
              <span>{isSpinning ? 'GIRANDO...' : 'GIRAR AGORA!'}</span>
            </button>

          </div>
        </div>

        {/* Low balance alert prompt */}
        {user.balanceLC < bet && (
          <div className="mt-4 p-3 bg-red-950/40 border border-red-500/30 rounded-xl flex items-center justify-between text-xs text-red-200">
            <span>Saldo insuficiente em Lula Coins para esta aposta ({bet} LC).</span>
            <button
              onClick={() => setActiveTab('deposit')}
              className="px-3 py-1 font-bold text-neutral-950 bg-amber-400 hover:bg-amber-300 rounded-lg shadow"
            >
              Recarregar via PIX
            </button>
          </div>
        )}
      </div>

    </div>
  );
};
