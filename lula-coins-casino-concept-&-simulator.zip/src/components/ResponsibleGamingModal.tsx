import React, { useState } from 'react';
import { ShieldAlert, Clock, Ban, DollarSign, HeartHandshake, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';

export const ResponsibleGamingModal: React.FC = () => {
  const {
    responsibleSettings,
    updateResponsibleSettings,
    sessionElapsedSeconds,
    endSelfExclusionForTesting,
  } = useCasino();

  const [depositLimit, setDepositLimit] = useState<number>(responsibleSettings.dailyDepositLimitBRL);
  const [lossLimit, setLossLimit] = useState<number>(responsibleSettings.dailyLossLimitLC);
  const [timeLimit, setTimeLimit] = useState<number>(responsibleSettings.sessionTimeLimitMinutes);
  const [exclusionPeriodHours, setExclusionPeriodHours] = useState<number>(24);
  const [savedSuccess, setSavedSuccess] = useState<string | null>(null);

  // Self assessment quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<number, boolean>>({});
  const [quizScore, setQuizScore] = useState<number | null>(null);

  const QUIZ_QUESTIONS = [
    'Você já jogou para tentar recuperar perdas de apostas anteriores?',
    'Já apostou quantias maiores do que pretendia inicialmente?',
    'Já sentiu ansiedade, inquietação ou irritabilidade quando tentou diminuir ou parar de jogar?',
    'O tempo gasto em jogos já interferiu nos seus compromissos familiares, profissionais ou de estudo?',
    'Já escondeu ou mentiu para pessoas próximas sobre o quanto apostou?',
  ];

  const handleSaveLimits = (e: React.FormEvent) => {
    e.preventDefault();
    updateResponsibleSettings({
      dailyDepositLimitBRL: depositLimit,
      dailyLossLimitLC: lossLimit,
      sessionTimeLimitMinutes: timeLimit,
    });
    setSavedSuccess('Limites de jogo responsável atualizados com sucesso!');
    setTimeout(() => setSavedSuccess(null), 3000);
  };

  const handleApplySelfExclusion = () => {
    const until = Date.now() + exclusionPeriodHours * 3600 * 1000;
    updateResponsibleSettings({
      isSelfExcluded: true,
      selfExclusionUntil: until,
    });
  };

  const handleCalculateQuiz = () => {
    const yesCount = Object.values(quizAnswers).filter(Boolean).length;
    setQuizScore(yesCount);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-red-500/40 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-red-400 font-bold flex items-center gap-1.5 mb-1">
            <ShieldAlert className="w-4 h-4 text-red-400" /> Diretrizes de Jogo Seguro & Proteção
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide text-neutral-100">
            PAINEL DE JOGO RESPONSÁVEL
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            Ferramentas mandatórias para controle financeiro, limites temporais e autoexclusão preventiva.
          </p>
        </div>

        {responsibleSettings.isSelfExcluded && (
          <div className="bg-red-950/90 border border-red-500 px-4 py-2.5 rounded-xl text-center">
            <span className="text-xs font-black text-red-200 block">STATUS: AUTOEXCLUSÃO ATIVA</span>
            <button
              onClick={endSelfExclusionForTesting}
              className="text-[11px] text-amber-300 underline font-semibold mt-1"
            >
              [Ambiente Teste: Encerrar Bloqueio]
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Limits & Self-Exclusion */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Limits Form */}
          <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>1. Configurar Limites Financeiros & Temporais</span>
            </h3>

            <form onSubmit={handleSaveLimits} className="space-y-4">
              
              <div>
                <label className="text-xs text-neutral-300 font-semibold block mb-1">
                  Limite Diário de Depósito via PIX (R$):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    step="10"
                    value={depositLimit}
                    onChange={(e) => setDepositLimit(Number(e.target.value))}
                    className="flex-1 bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2 text-sm text-neutral-100 font-mono-num focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-xs text-neutral-500 shrink-0">0 = sem limite</span>
                </div>
              </div>

              <div>
                <label className="text-xs text-neutral-300 font-semibold block mb-1">
                  Limite Diário de Perda em Moedas (LC):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    step="500"
                    value={lossLimit}
                    onChange={(e) => setLossLimit(Number(e.target.value))}
                    className="flex-1 bg-neutral-900 border border-neutral-700 rounded-xl px-4 py-2 text-sm text-neutral-100 font-mono-num focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-xs text-neutral-500 shrink-0">0 = sem limite</span>
                </div>
              </div>

              <div>
                <label className="text-xs text-neutral-300 font-semibold block mb-1">
                  Lembrete de Tempo de Sessão (Minutos):
                </label>
                <div className="grid grid-cols-4 gap-2 text-xs">
                  {[15, 30, 45, 60].map((mins) => (
                    <button
                      type="button"
                      key={mins}
                      onClick={() => setTimeLimit(mins)}
                      className={`py-2 rounded-xl font-bold transition-colors ${
                        timeLimit === mins
                          ? 'bg-amber-400 text-neutral-950 font-black'
                          : 'bg-neutral-900 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {mins} min
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-100 font-bold text-xs rounded-xl transition-colors border border-neutral-700"
              >
                Salvar Limites de Jogo
              </button>

              {savedSuccess && (
                <div className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5 p-2 bg-emerald-950/40 rounded-lg border border-emerald-500/20">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{savedSuccess}</span>
                </div>
              )}
            </form>
          </div>

          {/* Self-Exclusion Section */}
          <div className="p-6 bg-neutral-950 border border-red-950/80 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-red-400 uppercase tracking-wider flex items-center gap-2">
              <Ban className="w-4 h-4 text-red-400" />
              <span>2. Autoexclusão & Pausa Preventiva</span>
            </h3>

            <p className="text-xs text-neutral-400 leading-relaxed">
              Ao ativar a autoexclusão, todas as apostas e recargas PIX ficam estritamente bloqueadas durante o período selecionado para proteger sua saúde financeira e mental.
            </p>

            <div className="grid grid-cols-3 gap-2 text-xs">
              {[
                { label: '24 Horas', hours: 24 },
                { label: '7 Dias', hours: 168 },
                { label: '30 Dias', hours: 720 },
              ].map((opt) => (
                <button
                  key={opt.hours}
                  onClick={() => setExclusionPeriodHours(opt.hours)}
                  className={`py-2 rounded-xl font-bold border transition-all ${
                    exclusionPeriodHours === opt.hours
                      ? 'bg-red-900/80 border-red-400 text-red-200'
                      : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            <button
              onClick={handleApplySelfExclusion}
              className="w-full py-3 px-4 bg-gradient-to-r from-red-700 to-red-800 hover:from-red-600 hover:to-red-700 text-white font-black text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-red-900/30 transition-all flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>Confirmar Bloqueio de Autoexclusão</span>
            </button>
          </div>

        </div>

        {/* Right Column: Self-Assessment Quiz & Support Lines */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Quick Quiz */}
          <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-amber-400" />
              <span>Teste de Autoavaliação Rápido</span>
            </h3>

            <p className="text-[11px] text-neutral-400">
              Responda com honestidade para verificar se seu comportamento de jogo está saudável:
            </p>

            <div className="space-y-3">
              {QUIZ_QUESTIONS.map((q, idx) => (
                <div key={idx} className="p-2.5 bg-neutral-900/60 rounded-xl border border-neutral-800/80 space-y-1.5 text-xs">
                  <p className="text-neutral-300 text-[11px] leading-snug">{q}</p>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-neutral-400 hover:text-white">
                      <input
                        type="radio"
                        name={`quiz_${idx}`}
                        checked={quizAnswers[idx] === true}
                        onChange={() => setQuizAnswers(prev => ({ ...prev, [idx]: true }))}
                        className="accent-amber-400"
                      />
                      <span>Sim</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-neutral-400 hover:text-white">
                      <input
                        type="radio"
                        name={`quiz_${idx}`}
                        checked={quizAnswers[idx] === false}
                        onChange={() => setQuizAnswers(prev => ({ ...prev, [idx]: false }))}
                        className="accent-amber-400"
                      />
                      <span>Não</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>

            <button
              onClick={handleCalculateQuiz}
              className="w-full py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-xl transition-colors"
            >
              Verificar Resultado do Teste
            </button>

            {quizScore !== null && (
              <div
                className={`p-3 rounded-xl text-xs space-y-1 ${
                  quizScore >= 2
                    ? 'bg-red-950/80 border border-red-500/50 text-red-200'
                    : 'bg-emerald-950/80 border border-emerald-500/50 text-emerald-200'
                }`}
              >
                <div className="font-bold flex items-center gap-1">
                  {quizScore >= 2 ? <AlertTriangle className="w-4 h-4 text-red-400" /> : <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  <span>{quizScore >= 2 ? 'Alerta de Risco Detectado' : 'Comportamento Saudável'}</span>
                </div>
                <p className="text-[11px] opacity-90 leading-relaxed">
                  {quizScore >= 2
                    ? `Você respondeu "Sim" a ${quizScore} pergunta(s). Isso indica sinais de perda de controle. Recomendamos fazer uma pausa imediata e procurar os canais de apoio abaixo.`
                    : 'Suas respostas indicam que você mantém o jogo como entretenimento responsável. Continue sempre respeitando seus limites!'}
                </p>
              </div>
            )}
          </div>

          {/* Support Channels in Brazil */}
          <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-3">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
              Canais Gratuitos de Apoio Psicológico (Brasil)
            </h3>

            <div className="space-y-2 text-xs">
              <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                <span className="font-bold text-neutral-200 block">Jogadores Anônimos do Brasil</span>
                <span className="text-[11px] text-neutral-400 block mt-0.5">Grupo de apoio mútuo para jogadores compulsivos e familiares.</span>
                <a
                  href="https://jogadoresanonimos.com.br"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-amber-400 hover:underline text-[11px] flex items-center gap-1 mt-1 font-semibold"
                >
                  <span>jogadoresanonimos.com.br</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <div className="p-3 bg-neutral-900 rounded-xl border border-neutral-800">
                <span className="font-bold text-neutral-200 block">CVV - Centro de Valorização da Vida</span>
                <span className="text-[11px] text-neutral-400 block mt-0.5">Apoio emocional gratuito e sigiloso 24 horas por dia.</span>
                <div className="text-amber-400 text-xs font-mono font-bold mt-1">
                  Telefone: 188 (Ligação Gratuita)
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
