import React, { useState } from 'react';
import { Award, Sparkles, Gift, Zap, Shield, Check, Crown, Flame } from 'lucide-react';
import { useCasino } from '../context/CasinoContext';

const VIP_TIERS = [
  { name: 'Bronze', xpReq: 0, cashback: '2%', perk: 'Acesso padrão e bônus diário', color: 'from-amber-800 to-amber-950' },
  { name: 'Prata', xpReq: 500, cashback: '4%', perk: 'Saque prioritário e bônus semanal', color: 'from-slate-400 to-slate-700' },
  { name: 'Ouro', xpReq: 1000, cashback: '7%', perk: 'Cashback 7% e gerente exclusivo de conta', color: 'from-amber-400 to-yellow-600' },
  { name: 'Platina', xpReq: 2500, cashback: '10%', perk: 'Sem limite diário de saque e convites VIP', color: 'from-cyan-400 to-blue-700' },
  { name: 'Diamante', xpReq: 5000, cashback: '15%', perk: 'Cashback máximo 15% + Viagens e presentes', color: 'from-fuchsia-400 to-purple-800' },
];

const SHOP_ITEMS = [
  { id: 'free_spins_10', title: 'Pacote 10 Giros Grátis', priceLC: 400, desc: 'Giros no valor de 50 LC para o caça-níquel Lula Fortune', icon: Zap },
  { id: 'xp_boost_2x', title: 'Booster de XP 2x (1 Hora)', priceLC: 300, desc: 'Dobre seus pontos VIP em cada aposta feita na plataforma', icon: Flame },
  { id: 'loss_insurance', title: 'Seguro de Perda 50%', priceLC: 650, desc: 'Reembolsa 50% da sua próxima aposta perdedora em qualquer mesa', icon: Shield },
  { id: 'golden_badge', title: 'Emblema Dourado de Chat', priceLC: 800, desc: 'Destaque luminoso de prestígio no chat das mesas ao vivo', icon: Crown },
];

export const VipLoyalty: React.FC = () => {
  const { user, claimCashback, placeBet, registerWin } = useCasino();
  const [purchasedItems, setPurchasedItems] = useState<string[]>([]);
  const [shopFeedback, setShopFeedback] = useState<string | null>(null);

  const currentTierIndex = VIP_TIERS.findIndex(t => t.name === user.vipTier);
  const nextTier = VIP_TIERS[currentTierIndex + 1] || null;

  const xpProgress = nextTier
    ? Math.min(100, Math.round(((user.vipXP - VIP_TIERS[currentTierIndex].xpReq) / (nextTier.xpReq - VIP_TIERS[currentTierIndex].xpReq)) * 100))
    : 100;

  const handleClaim = () => {
    const claimed = claimCashback();
    if (claimed > 0) {
      setShopFeedback(`Sucesso! +${claimed.toLocaleString()} Lula Coins de cashback foram creditadas no seu saldo.`);
    }
  };

  const buyShopItem = (item: typeof SHOP_ITEMS[0]) => {
    if (user.balanceLC < item.priceLC) {
      setShopFeedback(`Saldo insuficiente para comprar ${item.title}.`);
      return;
    }

    const ok = placeBet('loja_recompensas', item.priceLC);
    if (ok) {
      setPurchasedItems(prev => [...prev, item.id]);
      setShopFeedback(`Parabéns! Você adquiriu "${item.title}". Ativado na sua conta.`);
      
      // If free spins, credit winnings back as reward
      if (item.id === 'free_spins_10') {
        registerWin('Loja de Recompensas - Giros', item.priceLC, 750);
      }
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5 mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Clube de Fidelidade Exclusivo
          </span>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
            NÍVEIS VIP & LOJA DE RECOMPENSAS
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300">
            A cada aposta você ganha XP, sobe de categoria e desbloqueia cashback crescente de até 15%!
          </p>
        </div>

        {/* Cashback Claim Box */}
        <div className="bg-neutral-950/90 border border-amber-500/40 p-4 rounded-xl flex items-center gap-4 shadow-lg shrink-0">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">Cashback Acumulado</span>
            <span className="text-xl font-black font-mono-num text-amber-300">
              {user.cashbackAvailableLC.toLocaleString()} LC
            </span>
          </div>

          <button
            disabled={user.cashbackAvailableLC <= 0}
            onClick={handleClaim}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              user.cashbackAvailableLC > 0
                ? 'bg-gradient-to-r from-amber-400 to-yellow-400 text-neutral-950 hover:brightness-110 shadow-md shadow-amber-500/20'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
            }`}
          >
            Resgatar
          </button>
        </div>
      </div>

      {/* VIP Progression Showcase */}
      <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs text-neutral-400 uppercase font-semibold">Seu Nível Atual:</span>
            <h2 className="text-2xl font-cinzel font-black text-amber-400 flex items-center gap-2">
              <Award className="w-6 h-6 text-amber-400" />
              <span>VIP {user.vipTier.toUpperCase()}</span>
            </h2>
          </div>

          <div className="text-right">
            <span className="text-xs text-neutral-400">Progresso Geral:</span>
            <div className="text-sm font-mono-num font-bold text-neutral-200">
              {user.vipXP} XP {nextTier ? `/ ${nextTier.xpReq} XP para ${nextTier.name}` : '(Nível Máximo Atingido!)'}
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-neutral-900 rounded-full h-3.5 border border-neutral-800 overflow-hidden relative">
          <div
            className="bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-300 h-full rounded-full transition-all duration-500 shadow-md shadow-amber-500/40"
            style={{ width: `${xpProgress}%` }}
          />
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 pt-2">
          {VIP_TIERS.map((tier, idx) => {
            const isCurrent = user.vipTier === tier.name;
            const isUnlocked = user.vipXP >= tier.xpReq;

            return (
              <div
                key={tier.name}
                className={`p-3.5 rounded-xl border flex flex-col justify-between transition-all ${
                  isCurrent
                    ? 'bg-neutral-900 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400'
                    : isUnlocked
                    ? 'bg-neutral-900/60 border-neutral-800'
                    : 'bg-neutral-950/40 border-neutral-900 opacity-60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-black uppercase text-neutral-200">{tier.name}</span>
                    {isCurrent && (
                      <span className="text-[9px] bg-amber-400 text-neutral-950 px-1 rounded font-extrabold">ATUAL</span>
                    )}
                  </div>
                  <div className="text-base font-black text-amber-400 font-mono-num">
                    {tier.cashback} <span className="text-[10px] text-neutral-400 font-normal">Cashback</span>
                  </div>
                  <div className="text-[10px] text-neutral-400 mt-1 leading-snug">
                    {tier.perk}
                  </div>
                </div>

                <div className="text-[10px] text-neutral-500 font-mono-num mt-2 pt-2 border-t border-neutral-800/80">
                  {tier.xpReq === 0 ? 'Inicial' : `${tier.xpReq} XP`}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Rewards Shop */}
      <div className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-neutral-800">
          <h3 className="text-sm font-bold text-neutral-200 uppercase tracking-wider flex items-center gap-2">
            <Gift className="w-4 h-4 text-amber-400" />
            <span>Loja de Recompensas & Vantagens</span>
          </h3>
          <span className="text-xs text-neutral-400">Troque suas Lula Coins por bônus instantâneos</span>
        </div>

        {shopFeedback && (
          <div className="p-3 bg-neutral-900 border border-amber-500/40 text-amber-300 text-xs rounded-xl flex items-center justify-between">
            <span>{shopFeedback}</span>
            <button onClick={() => setShopFeedback(null)} className="text-neutral-400 hover:text-white">✕</button>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SHOP_ITEMS.map((item) => {
            const Icon = item.icon;
            const isOwned = purchasedItems.includes(item.id);

            return (
              <div
                key={item.id}
                className="p-4 rounded-xl bg-neutral-900/80 border border-neutral-800 hover:border-neutral-700 flex flex-col justify-between transition-all"
              >
                <div>
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-3">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h4 className="text-xs font-bold text-neutral-200 leading-snug">{item.title}</h4>
                  <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">{item.desc}</p>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center justify-between">
                  <span className="text-xs font-mono-num font-bold text-amber-300">
                    {item.priceLC.toLocaleString()} LC
                  </span>
                  <button
                    disabled={isOwned || user.balanceLC < item.priceLC}
                    onClick={() => buyShopItem(item)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                      isOwned
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30 cursor-default'
                        : user.balanceLC < item.priceLC
                        ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        : 'bg-amber-400 hover:bg-amber-300 text-neutral-950 shadow-sm'
                    }`}
                  >
                    {isOwned ? 'Ativo ✓' : 'Comprar'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
