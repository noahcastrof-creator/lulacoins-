import React from 'react';
import { BookOpen, Coins, ShieldCheck, AlertTriangle, Workflow, Palette, Scale, Sparkles } from 'lucide-react';

export const WhitepaperConcept: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto space-y-8">
      
      {/* Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-red-950 via-neutral-900 to-amber-950 border border-amber-500/40 p-6 sm:p-8 shadow-xl flex flex-col md:flex-row items-center gap-6">
        <img
          src="/src/assets/images/lula_coins_logo_1792135128596.jpg"
          alt="Logo Lula Coins"
          className="w-20 h-20 rounded-full object-cover border-2 border-amber-400 shadow-2xl shadow-amber-500/40 shrink-0"
        />
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs uppercase tracking-widest text-amber-400 font-bold flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" /> Documentação de Produto & Engenharia
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-cinzel font-black tracking-wide gold-gradient-text">
            CONCEITO COMPLETO & TOKENOMICS: LULA COINS
          </h1>
          <p className="text-xs sm:text-sm text-neutral-300 max-w-3xl mt-1 leading-relaxed">
            Arquitetura econômica, psicologia de design, jornada do jogador e análise crítica do enquadramento regulatório brasileiro (Lei 14.790/2023).
          </p>
        </div>
      </div>

      {/* 1. Economia do Token (Tokenomics) */}
      <section className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-neutral-800">
          <Coins className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-cinzel font-bold text-neutral-100">
            1. Economia do Token: Lula Coins (LC)
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800">
            <span className="text-xs uppercase font-bold text-amber-400 block mb-1">Cotação & Paridade</span>
            <div className="text-xl font-black font-mono-num text-neutral-100">1 BRL = 100 LC</div>
            <p className="text-[11px] text-neutral-400 mt-1">
              Conversão decimal direta facilitando o cálculo mental do usuário e permitindo micropagamentos fracionados de apostas a partir de 10 LC (R$ 0,10).
            </p>
          </div>

          <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800">
            <span className="text-xs uppercase font-bold text-amber-400 block mb-1">Emissão (Faucets)</span>
            <div className="text-sm font-bold text-neutral-200 mt-1">Depósitos PIX + Bônus</div>
            <p className="text-[11px] text-neutral-400 mt-1">
              Moedas entram em circulação via depósitos PIX com bônus de boas-vindas progressivo (10% a 30%), streaks de login diário, roda da fortuna e recompensas de missões.
            </p>
          </div>

          <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800">
            <span className="text-xs uppercase font-bold text-amber-400 block mb-1">Queima & Taxa Reversa (Sinks)</span>
            <div className="text-sm font-bold text-neutral-200 mt-1">5% Taxa de Saque + House Edge</div>
            <p className="text-[11px] text-neutral-400 mt-1">
              A retenção de 5% no resgate PIX cobre custos de gateway e provisiona a reserva de liquidez. A margem matemática da casa (3% a 5%) garante sustentabilidade contínua.
            </p>
          </div>
        </div>

        <div className="p-4 bg-neutral-900/50 rounded-xl border border-neutral-800 text-xs text-neutral-300 leading-relaxed">
          <strong className="text-amber-400">Modelo Dual de Circulação:</strong> A Lula Coins funciona como um token utilitário no aplicativo (fechado para gameplay com alta velocidade e sem atrito de microtransações bancárias individuais por giro), com porta de entrada imediata via PIX e porta de saída de liquidez (troca reversa) transparente.
        </div>
      </section>

      {/* 2. Fluxo do Jogador: Do Cadastro ao Primeiro Giro */}
      <section className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-neutral-800">
          <Workflow className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-cinzel font-bold text-neutral-100">
            2. Fluxo do Usuário: Do Cadastro ao Primeiro Jogo
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          {[
            { step: '01', title: 'Onboarding Ágil', desc: 'Identificação por CPF com verificação de maioridade (+18) e termos de jogo responsável.' },
            { step: '02', title: 'Depósito PIX', desc: 'Geração imediata de QR Code e código Copia e Cola para a chave CPF 551.908.838-17.' },
            { step: '03', title: 'Crédito + Bônus', desc: 'Moedas Lula Coins caem no saldo instantaneamente com bônus de boas-vindas e XP VIP.' },
            { step: '04', title: 'Primeiro Giro', desc: 'Escolha intuitiva entre Caça-Níquel, Roleta, Blackjack ou Mesa Ao Vivo com áudio e feedback visual instantâneo.' },
            { step: '05', title: 'Loop de Retenção', desc: 'Missões diárias, cashback VIP acumulativo de até 15% e opção de saque rápido PIX.' },
          ].map((item) => (
            <div key={item.step} className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800 flex flex-col justify-between">
              <div>
                <span className="text-xs font-mono font-black text-amber-400">{item.step}.</span>
                <h3 className="text-xs font-bold text-neutral-200 mt-1">{item.title}</h3>
                <p className="text-[11px] text-neutral-400 mt-1 leading-relaxed">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Psicologia do Design & Hierarquia Visual */}
      <section className="p-6 bg-neutral-950 border border-neutral-800 rounded-2xl shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-2 border-b border-neutral-800">
          <Palette className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-cinzel font-bold text-neutral-100">
            3. Psicologia Visual: Vermelho, Dourado & Loops de Engajamento
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-neutral-300 leading-relaxed">
          <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800 space-y-2">
            <h4 className="font-bold text-red-400 uppercase tracking-wider text-[11px]">Vermelho Dominante (Adrenalina & Urgência)</h4>
            <p>
              Em neurodesign e cassinos de Macau e Las Vegas, o vermelho acelera a frequência cardíaca, desencadeia respostas fisiológicas de alerta e reduz a percepção de tempo decorrido. No produto, estimula a tomada de decisão rápida em giros e apostas de alta frequência.
            </p>
          </div>

          <div className="p-4 bg-neutral-900/80 rounded-xl border border-neutral-800 space-y-2">
            <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">Dourado Nobre (Recompensa & Prestígio)</h4>
            <p>
              O ouro evoca riqueza imediata, status elevado e poder adquisitivo. Animações de brilho dourado e pulsos radiantes ao vencer acionam o núcleo accumbens (centro de prazer e dopamina do cérebro), reforçando a repetição do loop de aposta.
            </p>
          </div>
        </div>
      </section>

      {/* 4. ADENDO HONESTO & ANÁLISE REGULATÓRIA NO BRASIL */}
      <section className="p-6 sm:p-8 bg-gradient-to-b from-red-950/80 to-neutral-950 border-2 border-red-500/60 rounded-2xl shadow-2xl space-y-5">
        <div className="flex items-center gap-2.5 pb-3 border-b border-red-900/60">
          <Scale className="w-6 h-6 text-red-400" />
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-red-400 block">
              ADENDO HONESTO & COMPLIANCE REGULATÓRIO
            </span>
            <h2 className="text-lg sm:text-xl font-cinzel font-bold text-white">
              Por Que Regulações de Jogo Responsável Proíbem Esses Elementos
            </h2>
          </div>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
          <p>
            Conforme apontado na solicitação, o uso de estímulos sensoriais hiper-viciantes (cores quentes estimulantes, sons de celebração contínuos e moedas fictícias) constitui o cerne das proibições das modernas legislações de apostas e jogos de cota fixa, incluindo o arcabouço brasileiro recém-instituído:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            
            <div className="p-4 bg-neutral-950/90 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-bold text-red-400 block">
                1. Proibição de Moedas Virtuais que Camuflam Valor Real
              </span>
              <p className="text-xs text-neutral-400 leading-normal">
                A legislação brasileira (Portarias da SPA/MF sob a Lei 14.790/2023) exige que todas as apostas e saldos sejam exibidos estritamente na <strong>moeda corrente nacional (Real - R$)</strong>. O uso de tokens intermediários ("Lula Coins") é frequentemente caracterizado como técnica predatória de "desconexão psicológica", pois diminui a dor percebida de perder dinheiro real.
              </p>
            </div>

            <div className="p-4 bg-neutral-950/90 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-bold text-red-400 block">
                2. Vedação ao Uso de Figuras Públicas & Políticas
              </span>
              <p className="text-xs text-neutral-400 leading-normal">
                As regras de publicidade do CONAR e da SPA/MF proíbem terminantemente vincular plataformas de apostas a personalidades políticas, governantes ou autoridades, além de vedar qualquer promessa de enriquecimento fácil ou ilusão de controle do jogador.
              </p>
            </div>

            <div className="p-4 bg-neutral-950/90 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-bold text-red-400 block">
                3. Proibição de "Perdas Disfarçadas de Vitórias" (LDWs)
              </span>
              <p className="text-xs text-neutral-400 leading-normal">
                Normas internacionais (como as da UKGC e órgãos da União Europeia) e regulatórias do Brasil vedam que caça-níqueis toquem trompetes triunfais ou emitam confetes quando o ganho é inferior ou igual à aposta feita (ex: apostar 100 LC e "ganhar" 20 LC com música de jackpot).
              </p>
            </div>

            <div className="p-4 bg-neutral-950/90 rounded-xl border border-neutral-800 space-y-1.5">
              <span className="text-xs font-bold text-red-400 block">
                4. Obrigatoriedade de Ferramentas Ativas de Proteção
              </span>
              <p className="text-xs text-neutral-400 leading-normal">
                Para qualquer operação legal, é obrigatório disponibilizar no front-end: relógio com tempo decorrido de sessão, limites autoimpostos de depósito e perda, botão de autoexclusão com integração aos cadastros restritivos nacionais e proibição expressa a menores de 18 anos.
              </p>
            </div>

          </div>

          <div className="p-4 bg-neutral-900/90 border border-amber-500/30 rounded-xl text-xs text-amber-200">
            <strong>Veredito Ético e Técnico:</strong> O aplicativo atual foi concebido integralmente como um <strong>simulador conceitual e educacional</strong>. Ele demonstra na prática o funcionamento dos loops de recompensa, ao mesmo tempo em que implementa as proteções de jogo responsável necessárias para demonstrar aos desenvolvedores e reguladores como balancear entretenimento e salvaguardas sociais.
          </div>
        </div>
      </section>

    </div>
  );
};
